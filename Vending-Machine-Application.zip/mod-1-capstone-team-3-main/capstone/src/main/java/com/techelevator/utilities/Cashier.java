package com.techelevator.utilities;

import java.math.BigDecimal;

public class Cashier {
    private BigDecimal balance;

    final BigDecimal QUARTER_VALUE = new BigDecimal("0.25");
    final BigDecimal DIME_VALUE = new BigDecimal("0.10");
    final BigDecimal NICKEL_VALUE = new BigDecimal("0.05");
    final BigDecimal PENNY_VALUE = new BigDecimal("0.01");

    public BigDecimal getBalance() {
        return balance;
    }
    public Cashier() {
        balance = new BigDecimal(0.00).setScale(2);
    }
    public BigDecimal feed(String feedAmt){
        balance = balance.add((new BigDecimal(feedAmt).setScale(2)));
        return balance;
    }
    public BigDecimal purchase(BigDecimal price){
        balance = balance.subtract(price);
        return balance;
    }
    public boolean isWholeNumber(String str){
        try{
            int number = Integer.parseInt(str);
            return true;
        }
        catch (NumberFormatException e){
            return false;
        }
    }
    public int calcQuarters () {

        int quarters = balance.divideToIntegralValue(QUARTER_VALUE).intValue();
        balance = balance.subtract(QUARTER_VALUE.multiply(new BigDecimal(quarters)));
        return quarters;
    }
    public int calcDimes() {

        int dimes = balance.divideToIntegralValue(DIME_VALUE).intValue();
        balance = balance.subtract(DIME_VALUE.multiply(new BigDecimal(dimes)));
        return dimes;
    }
    public int calcNickels() {

        int nickels = balance.divideToIntegralValue(NICKEL_VALUE).intValue();
        balance = balance.subtract(NICKEL_VALUE.multiply(new BigDecimal(nickels)));
        return nickels;
    }
    public int calcPennies(){
        int pennies = balance.divideToIntegralValue(PENNY_VALUE).intValue();
        balance = balance.subtract(PENNY_VALUE.multiply(new BigDecimal(pennies)));
        return pennies;
    }

}
