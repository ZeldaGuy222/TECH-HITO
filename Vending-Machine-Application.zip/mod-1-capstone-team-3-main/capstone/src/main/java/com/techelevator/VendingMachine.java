package com.techelevator;

import com.techelevator.utilities.*;



public class VendingMachine {
    Inventory inv = new Inventory();
    Cashier cash = new Cashier();
    Logger writer = new Logger("Vending.log");

    public Logger getWriter() {
        return writer;
    }

    public Inventory getInv() {
        return inv;
    }

    public Cashier getCash() {
        return cash;
    }

    public void restock(){
        inv.loadStockList();
    }


}
