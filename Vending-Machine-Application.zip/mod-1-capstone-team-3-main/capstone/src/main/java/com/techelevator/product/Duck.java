package com.techelevator.product;

import java.math.BigDecimal;

public class Duck extends StuffedAnimal {
    public Duck(String name, BigDecimal price) {
        super(name, price);
    }
    @Override
    public String makeNoise() {
        return "Quack, Quack, Splash!";
    }
}
