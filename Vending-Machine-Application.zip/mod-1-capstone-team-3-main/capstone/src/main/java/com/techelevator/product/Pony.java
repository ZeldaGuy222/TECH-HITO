package com.techelevator.product;

import java.math.BigDecimal;

public class Pony extends StuffedAnimal {
    public Pony(String name, BigDecimal price) {
        super(name, price);
    }
    @Override
    public String makeNoise() {
        return "Neigh, Neigh, Yay!";
    }
}
