package com.techelevator.utilities;
import java.io.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Logger {

    File destinationFileReference = new File("");

    LocalDateTime currentTime = LocalDateTime.now();
    String formattedTime = currentTime.format(DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm:ss"));


    public Logger(String logFilePath){
        try {
            destinationFileReference = new File(logFilePath);
            destinationFileReference.createNewFile();
        }
        catch(IOException e){
            System.out.println(e.getMessage());
        }
    }
    public String writePurchaseMessage(String name, String binID, BigDecimal price, BigDecimal updatedBalance){

        String message = formattedTime+" "+name+" "+binID+" $"+price+" $"+updatedBalance;
        writeLog(message);
        return message;
    }
    public String writeFeedMessage(BigDecimal moneyAdded, BigDecimal currentBalance){
        String message = formattedTime+" FEED MONEY: "+"$"+moneyAdded+" $"+currentBalance;
        writeLog(message);
        return message;

    }
    public String writeTransactionMessage(BigDecimal changeGiven, BigDecimal finalBalance){
        String message = formattedTime+" GIVE CHANGE: "+"$"+changeGiven+" $"+finalBalance;
        writeLog(message);
        return message;

    }
    public void writeLog(String message) {
        try(PrintWriter dataOutput = new PrintWriter(new FileOutputStream(destinationFileReference,true))){
            dataOutput.println(message);
        }catch(IOException io){
            System.out.println(io.getMessage());
        }
    }

}

