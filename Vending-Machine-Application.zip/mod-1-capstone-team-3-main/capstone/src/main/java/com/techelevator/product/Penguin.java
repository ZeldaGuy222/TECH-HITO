package com.techelevator.product;

import java.math.BigDecimal;

public class Penguin extends StuffedAnimal {
    public Penguin(String name, BigDecimal price) {
        super(name, price);
    }
    @Override
    public String makeNoise() {
        return "Squawk, Squawk, Whee!";
    }
}
