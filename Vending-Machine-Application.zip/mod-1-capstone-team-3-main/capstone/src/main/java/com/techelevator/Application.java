package com.techelevator;

import com.techelevator.product.StuffedAnimal;


import java.math.BigDecimal;
import java.util.Map;
import java.util.Scanner;

public class Application {

	static VendingMachine vm = new VendingMachine();
	static Scanner inputScanner = new Scanner(System.in);
	public static void main(String[] args) {
		//Instantiates Vending Machine and restock

		vm.restock();
		//Prompts user with first menu saves input to hande flow
		Integer userInput = handleInitialUserInput();

		//Menu Management
		boolean running = true;
		while(running) {
			if (userInput == 1) {
				//Present user with a list of all items in the vending machine with quantity remaining from the input file
				printInventory();
				userInput = handleInitialUserInput();

			}
			//Option 2 of Main Menu
			else if (userInput == 2) {
				Integer secondUserInput = handleSecondUserInput();
				if (secondUserInput == 1) {
					addBalancePrompt();
				}
				//Shows list of products available and allows the customer to enter a code to select an item
				else if (secondUserInput == 2) {
					printInventory();
					handleProductSelection();

				}
				//Complete transaction provide change and update balance to 0
				else {
					System.out.println("Transaction Complete");
					cashOut();
					userInput = handleInitialUserInput();
				}

			}
			//Option 3 on Main Menu
			else {
				System.out.println("Vending Session Ended");
				running = false;
			}
		}

	}

	public static void cashOut(){
		BigDecimal amountCashed = vm.cash.getBalance();
		int quarters = vm.cash.calcQuarters();
		int dimes = vm.cash.calcDimes();
		int nickels = vm.cash.calcNickels();
		int pennies = vm.cash.calcPennies();
		System.out.println("Dispensing Change");
		System.out.println(quarters+" Quarters, "+dimes+" Dimes, "+nickels+" Nickels, "+pennies+" Pennies");
		System.out.println("Ending Balance: "+vm.cash.getBalance());
		vm.getWriter().writeTransactionMessage(amountCashed,vm.cash.getBalance());

	}

	//Print Inventory
	public static void addBalancePrompt(){
		boolean keepAsking = true;
		while(keepAsking) {
			System.out.println("Current Money Provided is: $" + vm.getCash().getBalance());
			System.out.println("Please feed a whole dollar amount into the machine");
			String amount = inputScanner.nextLine();
			if(vm.cash.isWholeNumber(amount)){
				BigDecimal updatedAmount = vm.getCash().feed(amount);
				vm.getWriter().writeFeedMessage(new BigDecimal(amount), updatedAmount);
				keepAsking = false;
			}
			else{
				System.out.println("Incorrect input (please enter a whole number)");
			}
		}


	}
	public static void printInventory(){
		for (Map.Entry<String, StuffedAnimal> animal : vm.getInv().stockList.entrySet()) {
			String name = animal.getValue().getName();
			BigDecimal price = animal.getValue().getPrice();
			int quantity = animal.getValue().getInventory();
			System.out.println(animal.getKey()+":"+" | Name:"+name+" | Price:"+price+" | Quantity: "+quantity+" |");
		}
	}
	public static Integer handleInitialUserInput(){
		boolean badInput = true;
		Integer inputConverted = 0;
		while(badInput) {
			System.out.println();
			System.out.println("Main Menu");
			System.out.println("(1) Display Vending Machine Items");
			System.out.println("(2) Purchase");
			System.out.println("(3) Exit");
			String initialInput = inputScanner.nextLine();
			try {
				inputConverted = Integer.parseInt(initialInput);
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
			if(inputConverted==1||inputConverted==2||inputConverted==3){
				badInput = false;
			}
			else{
				System.out.println("Invalid Selection try again");
			}
		}
		return inputConverted;
	}
	public static Integer handleSecondUserInput(){
		boolean badInput = true;
		Integer inputConverted = 0;
		while(badInput) {
			System.out.println();
			System.out.println("Current Money Provided: $" + vm.getCash().getBalance());
			System.out.println();
			System.out.println("Purchasing Menu");
			System.out.println("(1) Feed Money");
			System.out.println("(2) Select Product");
			System.out.println("(3) Finish Transaction");
			String initialInput = inputScanner.nextLine();
			try {
				inputConverted = Integer.parseInt(initialInput);
			} catch (Exception e) {

			}
			if(inputConverted==1||inputConverted==2||inputConverted==3){
				badInput = false;
			}
			else{
				System.out.println("Invalid Selection try again");
			}
		}
		return inputConverted;
	}
	public static void handleProductSelection(){

		System.out.println();
		System.out.println("Please Select a product: ");
		boolean haveKey = false;

		String productSelection = inputScanner.nextLine();
		for (Map.Entry<String, StuffedAnimal> animal : vm.getInv().stockList.entrySet()) {
			if(productSelection.equals(animal.getKey())){
				haveKey = true;
				if(animal.getValue().getPrice().compareTo(vm.cash.getBalance())>0){
					System.out.println("Insufficient Funds");

				}
				else if(animal.getValue().getInventory() > 0){

					 vm.cash.purchase(animal.getValue().getPrice());
					 String name = animal.getValue().getName();
					 BigDecimal cost = animal.getValue().getPrice();
					 System.out.println("Dispensing item:" +name+" Cost:" +cost+" Message:"+animal.getValue().makeNoise());
					 animal.getValue().reduceInventory();
					 vm.getWriter().writePurchaseMessage(name, animal.getKey(), cost, vm.cash.getBalance());

				} else{
					System.out.println("Item out of Stock");
				}
			}
		}
		if(haveKey == false){
			System.out.println("Invalid selection, please try again!");
		}
	}
}
