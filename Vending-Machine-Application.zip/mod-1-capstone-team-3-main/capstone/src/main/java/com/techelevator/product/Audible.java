package com.techelevator.product;

public interface Audible {
    public String makeNoise();
}
