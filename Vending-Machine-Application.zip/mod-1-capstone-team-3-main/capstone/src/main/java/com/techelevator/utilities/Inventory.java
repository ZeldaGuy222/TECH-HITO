package com.techelevator.utilities;

import com.techelevator.product.*;

import java.io.File;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class Inventory {
    private static final String DEFAULT_INVENTORY = "vendingmachine.csv";
    public Map<String, StuffedAnimal> stockList;

    public Map<String, StuffedAnimal> getStockList() {
        return stockList;
    }

    public Inventory(){
        stockList = new HashMap<>();
    }

    public void loadStockList(){
        try{
            File dataFile = new File(DEFAULT_INVENTORY);
            try(Scanner fileScanner = new Scanner(dataFile)){
                while (fileScanner.hasNextLine()){
                    String nextLine = fileScanner.nextLine();
                    String[] data = nextLine.split(",");
                    String binID = data[0];
                    if(data[3].equals("Cat")){
                        Cat newAnimal = new Cat(data[1], new BigDecimal(data[2]));
                        stockList.put(binID,newAnimal);
                    }
                    else if(data[3].equals("Penguin")){
                        Penguin newAnimal = new Penguin(data[1], new BigDecimal(data[2]));
                        stockList.put(binID,newAnimal);
                    }
                    else if(data[3].equals("Pony")){
                        Pony newAnimal = new Pony(data[1], new BigDecimal(data[2]));
                        stockList.put(binID,newAnimal);
                    }
                    else if (data[3].equals("Duck")){
                        Duck newAnimal = new Duck(data[1], new BigDecimal(data[2]));
                        stockList.put(binID,newAnimal);
                    }

                }
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

}

