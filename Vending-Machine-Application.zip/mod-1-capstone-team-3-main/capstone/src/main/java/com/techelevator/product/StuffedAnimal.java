package com.techelevator.product;

import java.math.BigDecimal;

public class StuffedAnimal implements Audible {
    private String name;
    private BigDecimal price;

    private int inventory = 5;
    public void reduceInventory(){
        inventory--;
    }

    public String getName() {
        return name;
    }
    public BigDecimal getPrice() {
        return price;
    }
    public int getInventory() {
        return inventory;
    }
    public StuffedAnimal(String name, BigDecimal price){
        this.name = name;
        this.price = price;
    }
    @Override
    public String makeNoise() {
        return "";
    }

}
