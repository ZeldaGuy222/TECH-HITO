package com.techelevator;

import com.techelevator.product.StuffedAnimal;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;


@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class VendingMachineTest {
	LocalDateTime currentTime = LocalDateTime.now();
	String formattedTime = currentTime.format(DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm:ss"));

	VendingMachine vmTest = new VendingMachine();
	@Before
	public void setUp(){
		vmTest.inv.loadStockList();
		vmTest.cash.feed("20");
		StuffedAnimal animal = vmTest.inv.getStockList().get("A1");
		for(int i = 1; i<=5; i++){
			animal.reduceInventory();
			vmTest.cash.purchase(new BigDecimal("0.90"));
		}
		//Initializes a state before every test, where A1 is sold out, balance is 15.50
	}
	@Test
	public void feedTestNotWholeNumber() {
		String notWholeNum = "5.5";
		if(vmTest.cash.isWholeNumber(notWholeNum)){
			vmTest.cash.feed(notWholeNum);
		}
		//Balance should not change as String is not a whole number
		Assert.assertEquals(new BigDecimal("15.50"), vmTest.cash.getBalance());
	}

	@Test
	public void feedTestWholeNumber() {
		String wholeNum = "5";
		if(vmTest.cash.isWholeNumber(wholeNum)){
			vmTest.cash.feed(wholeNum);
		}
		//Balance should not increase by 5 as String is a whole number (15.50+5) = 20.50
		Assert.assertEquals(new BigDecimal("20.50"), vmTest.cash.getBalance());
	}
	@Test
	public void calcQuartersTest() {
		//Balance is 15.50 so we know there should be 62 quarters returned (62*.25 = 15.50)
		int quarters = vmTest.cash.calcQuarters();
		Assert.assertEquals(62, quarters);
	}
	@Test
	public void calcDimesTest() {
		//Balance is 15.50 so there should be 155 dimes returned(normally calc quarters is called first but isolating calcDimes)
		int dimes = vmTest.cash.calcDimes();
		Assert.assertEquals(155, dimes);
	}
	@Test
	public void calcNickelsTest() {
		//Balance is 15.50 so we know there should be 310 nickels returned (normally calc quarters is called first but isolating calcNickels)
		int nickels = vmTest.cash.calcNickels();
		Assert.assertEquals(310, nickels);
	}
	@Test
	public void calcPenniesTest() {
		//Balance is 15.50 so we know there should be 1550 pennies returned (normally calc quarters is called first but isolating calcPennies)
		int pennies = vmTest.cash.calcPennies();
		Assert.assertEquals(1550, pennies);
	}

	@Test
	public void purchaseTest() {
		StuffedAnimal animal = vmTest.inv.getStockList().get("A4");
		//Price is 2.00
		BigDecimal updatedPrice = vmTest.cash.purchase(animal.getPrice());
		//Balance should be 13.50 after purchasing 2.00 item
		Assert.assertEquals(new BigDecimal("13.50"), vmTest.cash.getBalance());
	}
	@Test
	public void loadStockListNameTest(){
		StuffedAnimal animal = vmTest.inv.getStockList().get("A4");
		//Item at A4 should have name "Bat Duck"
		Assert.assertEquals("Bat Duck",animal.getName());
	}

	@Test
	public void loadStockListPriceTest(){
		StuffedAnimal animal = vmTest.inv.getStockList().get("A4");
		//Item at A4 should have price of 2.00
		Assert.assertEquals(new BigDecimal("2.00"),animal.getPrice());
	}

	@Test
	public void loadStockListQuantityTest(){
		StuffedAnimal animal = vmTest.inv.getStockList().get("A1");
		//Item at A1 should have a quantity of 0 as it what sold out in test initializer
		Assert.assertEquals(0,animal.getInventory());
	}
	@Test
	public void writePurchaseMessageTest(){
		StuffedAnimal animal = vmTest.inv.getStockList().get("A1");
		String actual = vmTest.writer.writePurchaseMessage(animal.getName(), "A1", animal.getPrice(),new BigDecimal("0"));
		String expected = formattedTime+" "+animal.getName()+" "+"A1"+" $"+animal.getPrice()+" $"+new BigDecimal("0");
		Assert.assertEquals(expected, actual);


	}
	@Test
	public void writeTransactionMessageTest(){
		String actual = vmTest.writer.writeTransactionMessage(new BigDecimal("5"), new BigDecimal("0"));
		String expected = formattedTime+" GIVE CHANGE: "+"$"+new BigDecimal("5")+" $"+new BigDecimal("0");
		Assert.assertEquals(expected, actual);
	}
	@Test
	public void writeFeedMessageTest(){
		String actual  = vmTest.writer.writeFeedMessage(new BigDecimal("5"), new BigDecimal("5"));
		String expected = formattedTime+" FEED MONEY: "+"$"+new BigDecimal("5")+" $"+new BigDecimal("5");
		Assert.assertEquals(expected, actual);
	}
}
