package com.techelevator.tenmo.services;

import com.techelevator.tenmo.model.AuthenticatedUser;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestTemplate;

import java.util.List;

public class AuthenticatedAPIService {
    protected String BASE_URL;
    protected final RestTemplate restTemplate = new RestTemplate();
    protected String authToken = null;

    public void setAuthToken(String authToken) {
        this.authToken = authToken;
    }

    protected HttpEntity<Void> makeAuthEntity(){
            HttpHeaders headers = new HttpHeaders();
            headers.setBearerAuth(authToken);
            return new HttpEntity<>(headers);
    }
}
