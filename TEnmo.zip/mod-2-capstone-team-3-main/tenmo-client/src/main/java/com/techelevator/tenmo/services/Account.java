package com.techelevator.tenmo.services;

import com.techelevator.tenmo.model.AuthenticatedUser;
import com.techelevator.util.BasicLogger;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestClientResponseException;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

public class Account extends AuthenticatedAPIService {
    public Account(String BASE_URL) {
        this.BASE_URL = BASE_URL + "/account/";
    }

    public BigDecimal getBalance() {
        BigDecimal balance = new BigDecimal(1000);
        try {
            ResponseEntity<BigDecimal> response = restTemplate.exchange(BASE_URL + "balance", HttpMethod.GET, makeAuthEntity(),
                    BigDecimal.class);
            balance = response.getBody();
        } catch (RestClientResponseException e) {
            BasicLogger.log(e.getRawStatusCode() + " : " + e.getStatusText());
        } catch (ResourceAccessException e) {
            BasicLogger.log(e.getMessage());
        }
        return balance;
    }

    public List<Transfer> getTransferHistory(AuthenticatedUser currentUser) {
        return null;
    }

    public List<Transfer> getPendingRequests(AuthenticatedUser currentUser) {

        return null;
    }

    public boolean sendTEBucks(AuthenticatedUser currentUser, int userId, BigDecimal amount) {
        return false;
    }

    public Map<Integer, String> listUsersExceptCurrent(AuthenticatedUser currentUser) {
        return null;
    }

    public boolean requestTEBucks(AuthenticatedUser currentUser, int userId, BigDecimal amount) {
        return false;
    }
}
