package com.techelevator.tenmo.controller;

import com.techelevator.tenmo.dao.AccountDao;
import com.techelevator.tenmo.dao.TransferDao;
import com.techelevator.tenmo.dao.UserDao;
import com.techelevator.tenmo.model.Account;
import com.techelevator.tenmo.model.Transfer;
import com.techelevator.tenmo.security.SecurityUtils;
import org.jboss.logging.BasicLogger;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.math.BigDecimal;

public class TransferController {

    private final UserDao userDao; // created
    private final TransferDao transferDao;
    private final AccountDao accountDao;

    public TransferController(AccountDao accountDao, UserDao userDao, TransferDao transferDao, TransferDao transferDao1) {
        this.accountDao = accountDao;
        this.userDao = userDao;
        this.transferDao = transferDao1;
    }

    // step 3 see account balance
    @RequestMapping(path = "/transfer", method = RequestMethod.GET)

    public Transfer sendTEBucks(int fromUserId, int toUserId, BigDecimal amount) throws Exception {

        // Check if from user is trying to send money to themselves
        if (fromUserId == toUserId) {
            throw new Exception("Self transfer is not allowed.");
        }
        // Validate amount
        if (amount.compareTo(BigDecimal.ZERO) <= 0) {
            throw new Exception("Invalid amount specified.");
        }
        // Fetch from and to account balances
        BigDecimal fromAccountBalance = accountDao.getAccountBalanceByAccountId(fromUserId);
        BigDecimal toAccountBalance = accountDao.getAccountBalanceByAccountId(toUserId);
        // Check if both from and to accounts exist
        if (fromAccountBalance == null || toAccountBalance == null) {
            throw new Exception("Account not found.");
        }
        // Check if from user has sufficient funds
        if (fromAccountBalance.compareTo(amount) < 0) {
            throw new Exception("Insufficient funds.");
        }
        // Create Transfer object
        Transfer transfer = new Transfer(fromUserId, toUserId, amount, Transfer.APPROVED);

        // Send money
        try {
            transferDao.sendMoney(fromUserId, toUserId, amount);
        } catch (Exception e) {
            throw new Exception("Error processing money transfer", e);
        }

        // Return the transfer
        return transfer;
    }
}
