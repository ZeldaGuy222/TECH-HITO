package com.techelevator.tenmo.controller;

public class UserController {
}
