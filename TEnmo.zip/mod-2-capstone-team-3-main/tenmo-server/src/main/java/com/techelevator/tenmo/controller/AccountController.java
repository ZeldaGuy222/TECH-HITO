package com.techelevator.tenmo.controller;

import com.techelevator.tenmo.exception.DaoException;
import org.springframework.security.access.prepost.PreAuthorize;
import com.techelevator.tenmo.dao.AccountDao;
import com.techelevator.tenmo.dao.UserDao;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import java.math.BigDecimal;
import java.security.Principal;


@RestController
@PreAuthorize("isAuthenticated()")
@RequestMapping("/account")
public class AccountController {
    private final UserDao userDao; // created
    private final AccountDao accountDao;

    public AccountController(AccountDao accountDao, UserDao userDao) {
        this.accountDao = accountDao;
        this.userDao = userDao;
    }


//     step 3
    @RequestMapping(path = "/balance", method = RequestMethod.GET)
    public void getAccountBalance(Principal principal) throws UsernameNotFoundException {
        int userId = getUserIdFromUsername(principal);
        try {
            BigDecimal accountBalanceById = accountDao.getAccountBalanceByUserID(userId);
        } catch (DaoException e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    //

    private int getUserIdFromUsername(Principal principal) {
        int user = userDao.getUserByUsername(principal.getName()).getId();
        return user;
    }



//
//    // step 3 see account balance
//    @RequestMapping(path = "/balance", method = RequestMethod.GET)
//    public BigDecimal getAccountBalance(Principal principal) throws UsernameNotFoundException {
//        int userId = getUserIdFromUsername(principal);
//
//        public LoginResponseDto login ( LoginDto loginDto)
//        {
//
//            UsernamePasswordAuthenticationToken authenticationToken =
//                    new UsernamePasswordAuthenticationToken(loginDto.getUsername(), loginDto.getPassword());
//
//            Context authenticationManagerBuilder;
//            Authentication authentication = authenticationManagerBuilder.getObject().authenticate(authenticationToken);
//            SecurityContextHolder.getContext().setAuthentication(authentication);
//            String jwt = tokenProvider.createToken(authentication, false);
//
//
//
//           /* User user;
//            try {
//                Account account = accountDao.getAccountByUserId(userId);
//                return account.getBalance();
//            } catch (DaoException e) {
//                throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR);
//            }









}
