package com.techelevator.tenmo.dao;

import java.math.BigDecimal;

public interface AccountDao {



    BigDecimal getAccountBalanceByUserID(int userID);

    BigDecimal getAccountBalanceByUsername(String username);

    BigDecimal getAccountBalanceByAccountId(int accountId);


    void setBalance(int accountId, BigDecimal amount);


}
