package com.techelevator.tenmo.dao;

import com.techelevator.tenmo.model.Transfer;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class JdbcTransferDao implements TransferDao {
    private final JdbcTemplate jdbcTemplate;

    public JdbcTransferDao(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;

    }

    @Override
    public List<Transfer> getUserTransfers(int accountId) {
        List<Transfer> transfers = new ArrayList<>();
        String sql = "SELECT * FROM transfer WHERE account_from = ? OR account_to = ?";
        try {
            SqlRowSet results = jdbcTemplate.queryForRowSet(sql, accountId, accountId);
            while (results.next()) {
                transfers.add(mapRowToTransfer(results));
            }
        } catch (Exception e) {
            throw new RuntimeException("Error fetching user transfers", e);
        }
        return transfers;
    }

    @Override
    public Transfer getTransferById(int transferId) {
        Transfer transfer = null;
        String sql = "SELECT * FROM transfer WHERE transfer_id = ?";
        try {
            SqlRowSet results = jdbcTemplate.queryForRowSet(sql, transferId);
            if (results.next()) {
                transfer = mapRowToTransfer(results);
            }
        } catch (Exception e) {
            throw new RuntimeException("Error fetching transfer by ID", e);
        }
        return transfer;
    }

    @Override
    public void sendMoney(int fromAccountId, int toAccountId, BigDecimal amount) {
        // NEED TO BE ABLE TO SEND AND RECEIVE MONEY IN THIS METHOD -- UNSURE HOW TO IMPLEMENT THESE ACTIONS
        // INTO THE SAME TRY CATCH STATEMENT

        String insertTransferSql = "INSERT INTO transfer (transfer_type_id, transfer_status_id, account_from, account_to, amount) VALUES (2, 2, ?, ?, ?)";
        String updateAccountFromSql = "UPDATE account SET balance = balance - ? WHERE account_id = ?";
        String updateAccountToSql = "UPDATE account SET balance = balance + ? WHERE account_id = ?";
        try {
            jdbcTemplate.update(insertTransferSql, fromAccountId, toAccountId, amount);
            jdbcTemplate.update(updateAccountFromSql, amount, fromAccountId);
            jdbcTemplate.update(updateAccountToSql, amount, toAccountId);
        } catch (Exception e) {
            throw new RuntimeException("Error processing money transfer", e);
        }
    }
    @Override
    public Transfer saveTransfer(Transfer transfer) {
        String sql = "INSERT INTO transfer (transfer_type_id, transfer_status_id, account_from, account_to, amount) " +
                "VALUES (?, ?, ?, ?, ?) RETURNING transfer_id;";
        int transferId = jdbcTemplate.queryForObject(sql, new Object[]{
                transfer.getTransferTypeId(), transfer.getTransferStatusId(), transfer.getFromUserId(),
                transfer.getToUserId(), transfer.getAmount()}, Integer.class);
        transfer.setTransferId(transferId);
        return transfer;
    }
    //
    private Transfer mapRowToTransfer(SqlRowSet results) throws Exception {
        int transferId = results.getInt("transfer_id");
        int transferTypeId = results.getInt("transfer_type_id");
        int transferStatusId = results.getInt("transfer_status_id");
        int fromUserId = results.getInt("account_from");
        int toUserId = results.getInt("account_to");
        BigDecimal amount = results.getBigDecimal("amount");
        return new Transfer(fromUserId, toUserId, amount, transferTypeId, transferStatusId);
    }

}
