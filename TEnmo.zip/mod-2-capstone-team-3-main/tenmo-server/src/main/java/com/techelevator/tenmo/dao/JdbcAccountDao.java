package com.techelevator.tenmo.dao;

import com.techelevator.tenmo.exception.DaoException;
import com.techelevator.tenmo.model.Account;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
// changed string


@Component
public class JdbcAccountDao implements AccountDao {
    private static final BigDecimal STARTING_BALANCE = new BigDecimal("1000.00");
    private final JdbcTemplate jdbcTemplate;

    public JdbcAccountDao(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }


    @Override
    public BigDecimal getAccountBalanceByUserID(int userId) {
        BigDecimal accountBalanceById = null;
        String sql = "SELECT + WHERE user_id =?";


        try {
            accountBalanceById = jdbcTemplate.queryForObject(sql, BigDecimal.class, userId);
        } catch (CannotGetJdbcConnectionException e) {
            throw new DaoException("Unable to connect to server or database", e);
        } catch (DataIntegrityViolationException e) {
            throw new DaoException("Data integrity violation", e);
        }
        return accountBalanceById;

    }

    @Override
    public BigDecimal getAccountBalanceByAccountId(int accountId) {
        BigDecimal accountBalance = null;
        String sql = "SELECT + WHERE account_id =?";

        try {
            accountBalance = jdbcTemplate.queryForObject(sql, BigDecimal.class, accountId);
        } catch (CannotGetJdbcConnectionException e) {
            throw new DaoException("Unable to connect to server or database", e);
        } catch (DataIntegrityViolationException e) {
        throw new DaoException("Data Integrity violation", e);
    }
    return accountBalance;
}

@Override
public BigDecimal getAccountBalanceByUsername(String username) {

        BigDecimal accountBalanceByUsername = null;
        String sql = "SELECT + JOIN tenmo_user ON account.user_id = tenmo_user.user_id" +
                "+ WHERE username ILIKE ?";
        try {
            accountBalanceByUsername = jdbcTemplate.queryForObject(sql, BigDecimal.class, username);
        } catch (CannotGetJdbcConnectionException e) {
            throw new DaoException("Unable to connect to server", e);
        } catch (DataIntegrityViolationException e) {
            throw new DaoException("Data integrity violation", e);
        }
        return accountBalanceByUsername;
}

    @Override
    public void setBalance(int accountId, BigDecimal amount) {
        String sql = "UPDATE account SET balance = balance + ? WHERE account_id = ?";
        jdbcTemplate.update(sql, amount, accountId);
    }



    private Account mapRowToAccount(SqlRowSet rs) {
        Account account = new Account(rs.getInt("account_id"), rs.getInt("user_id"), rs.getBigDecimal("balance"));
        return account;
    }

    private Account mapRowToUser(SqlRowSet rs) {
        Account account = new Account();
        account.setAccountId(rs.getInt("account_id"));
        account.setUserId(rs.getInt("user_id"));
        account.setBalance(rs.getBigDecimal("balance"));
        return account;
    }
}

// getAccountBalanceByAccountId
// getAccountBalanceByUserId
// -----------------------------------------
// getAccountBalanceUsername
// addFunds
// subtractFunds