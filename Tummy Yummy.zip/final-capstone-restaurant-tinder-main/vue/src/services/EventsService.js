import axios from 'axios';

export default {

    create (ev) {
        return axios.post (`/events`, ev);
    },

    getEvents (id) {
        return axios.get (`/events`);
    },

    getEvent (id) {
        return axios.get (`/events/${id}`);
    },

    updateEvent (ev) {
        return axios.put (`/events/${ev.id}`,ev);
    },


}
