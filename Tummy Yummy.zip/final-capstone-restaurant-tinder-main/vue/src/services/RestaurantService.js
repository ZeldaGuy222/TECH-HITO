import axios from 'axios';

export default {

    getRestaurants (srch,radius,vegan,vegetarian,allRest) {
        return axios.get (`/restaurants?search=${srch}&vegan=${vegan}&vegetarian=${vegetarian}&allRest=${allRest}&radius=${radius}`);
    },

    getRestaurant (restId,userId) {
        return axios.get (`/event/${restId}/${userId}`);
    },

    updateRestaurant (eventId,restId,userId,value) {
        return axios.put (`/event/${eventId}/${restId}/${userId}?value=${value}`);
    },
    SaveComment (comment){
        return axios.post('/restaurants/comments',comment);
    }

}
