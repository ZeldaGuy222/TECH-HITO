<template>
    <div class="header">
        <div class="side-bar">            
            <criteria />
            <selected :title="title" />
        </div> 
        <RestaurantList /> 
    </div>
  
</template>

<script>
import RestaurantList from '../components/RestaurantList.vue';
import Selected from '../components/Selected.vue';
import Criteria from '../components/Criteria.vue';

export default {
    props: ['title'],
    components:{
        RestaurantList,
        Selected,
        Criteria
    },     
}

const x = document.getElementById("demo");

function getLocation() {
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(showPosition);
  } else {
    x.innerHTML = "Geolocation is not supported by this browser.";
  }
}

function showPosition(position) {
  x.innerHTML = "Latitude: " + position.coords.latitude +
  "<br>Longitude: " + position.coords.longitude;
}

</script>

<style scoped>

.side-bar{
    margin-left: 20px;
    position: absolute;
    
}

</style>