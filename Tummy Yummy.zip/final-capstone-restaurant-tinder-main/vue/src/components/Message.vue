<template>
    <div class="msg-bar">
        <div :class="{'success': $store.state.message.type == 'success', 'info': $store.state.message.type == 'info', 'error': $store.state.message.type == 'error'}" v-if="$store.state.message.text">
            <span class="msg-text">{{ $store.state.message.text }}</span>
            <span><button class="msg-dismiss" @click="resetMessage">Dismiss</button></span>
        </div>
    </div>
</template>

<script>
export default {
    methods:{
        resetMessage(){
            this.$store.commit('SET_MESSAGE',{});
        }
    }
}
</script>

<style scoped>
.msg-bar{
   display: grid;
   text-align: center;
}
.success {
    border: solid 2px darkgreen;
    background-color: lightgreen;
    color: darkgreen;
}

.info{
    border: solid 2px darkgreen;
    background-color: yellow;
    color: darkgreen;
}

.error{
    border: solid 2px darkred;
    background-color: rgb(255, 132, 132);
    color: darkred;
}

.msg-text {
    font-weight: bold;
    padding-left:30px;
}

.msg-dismiss {
    background-color: #ffffff00;
    border: none;
    text-decoration: underline;
    cursor: pointer;
    padding-left:20px;
}
</style>