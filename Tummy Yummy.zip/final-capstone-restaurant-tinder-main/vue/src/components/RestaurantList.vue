
<template>
    <div class = "outer_box"> 
    <restaurant 
      v-for="restaurant in filteredRestaurants"
      v-bind:key="restaurant.id"
      v-bind:restaurant="restaurant"
    />
  </div>
</template>

<script>
import Restaurant from './Restaurant.vue';

export default {
  components:{
    Restaurant
  },
  beforeRouteLeave(){
      this.$store.commit('SET_MESSAGE' ,{});
  },
  computed:{
    filteredRestaurants(){
      const restaurantFilter = this.$store.state.filter;
      if(this.$store.state.event.restaurantList === undefined){
        return;
      }

      const restaurants = this.$store.state.event.restaurantList;
      return restaurants.filter(restaurant => {
        return this.$store.state.restaurantFilter.length === 0;
        
      });
    }
  }
}
</script>

<style>
.outer_box{
  max-width: 500%;
  min-width: 50%;
}
</style>