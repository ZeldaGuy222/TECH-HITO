<template>
    <div class="R-List">List of Restaurants
             <ul>
                <li v-for="res in $store.state.selectedList" v-bind:key="res" :value="res.id"> {{ res.name }} </li>
            </ul>      
            <div class="submit-event-button"><button @click="addNewEvent">Submit</button> </div>      
       </div>
</template>

<script>
import eventService from '../services/EventsService';

export default {
    methods:{
        addNewEvent(){
            this.$store.commit("SET_EVENT_RESTAURANTS");            
            
            // call axios service to create event
            if(this.$route.params.event_id == '0'){
                this.$store.commit("SET_HOST_ID");
                eventService.create(this.$store.state.event)
                 .then(response =>{
                    this.$store.commit('CLEAR_EVENT'); //ADDED
                    this.$router.push({name:'user'});
                })
                .catch(error => {
                    const response = error.response;
                });
            }else{
                eventService.updateEvent(this.$store.state.event)
                .then(response =>{                    
                    this.$router.push({name:'user'});
                })
                .catch(error => {
                    const response = error.response;
                });
            }      
        }
    }
}
</script>

<style scoped>

.R-List{
    background-color: rgba(230, 63, 63, 0.250);     /* brown(230, 63, 63); */
    min-height: 100px;
    font-weight: bold;
    padding: 10px;
    text-align: left; 
    font-size: 18px;
    border-radius: 20px;
    border: solid 1px brown;
    text-align:center;
    margin-top: 275px;
    margin-left: 50px;
    width: 250px;


}
.R-List ul{
    margin-top:15px;
    text-align:left;
    font-size: 20px;
}
.R-List li{
   font-weight: bold;
    width: 190px;
    font-weight: normal;
    margin-top:2px;
}


.submit-event-button{
    /* style submit button  */
    margin-top: 50px;
}
</style>