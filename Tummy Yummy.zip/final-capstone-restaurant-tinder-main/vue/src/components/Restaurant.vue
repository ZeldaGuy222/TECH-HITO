<template>
  <div class="container">
    
      <div class="grid-container">
          <div class="title">{{ restaurant.name }}</div>
          <div class="grid-item image">
              <img :src="getImagePath()" alt="Image"/>
              
          </div>
          <div class="grid-item details">
              <div class="rating-stars">
                <img class="stars" v-for="n in getFullStars()" :src="fullStarUrl" :key="n" />
                <img class="stars" v-for="h in getHalfStars()" :src="halfStarUrl" :key="h" />
                <img class="stars" v-for="e in getEmptyStars()" :src="emptyStarUrl" :key="e" />
                <span class="rating-number">{{ parseFloat(restaurant.rating).toFixed(1) }}</span>
                <span class="review-count"> ({{restaurant.review_count}} Reviews)</span>
    
              </div> 
              <div class="price-range">Price: {{ priceLevel }}</div>
              <div class="tags"><span class="tag" v-for="tag in categoryList" :key="tag">{{ tag }}</span></div>
              <div class="address">{{restaurant.location.address1}}<br>{{restaurant.location.city}}, {{ restaurant.location.state }} {{ restaurant.location.zip_code }}</div>
              <div class="distance">{{ calculateDistance }}</div>
              <div class="phone">{{ restaurant.display_phone }}</div>
              <div class="more-info">  

                <a :href='`tel:${formattedPhone}`' value="Call" v-if="restaurant.display_phone" class="call-button">Call</a>                
                <a :href='`${restaurant.url}`' target="_blank" class="website-button " value="Website" v-if="restaurant.url">Website</a>
               
                <div class="comment-box">
                    <label> Comment </label>
                    <textarea v-model="comment" rows = "5"></textarea><button @click="SaveComment" class="comment-button">Save Comment</button> 
                </div>
            </div>
          </div>
          
          <div class="grid-item hours">
              <div class = "HOP"> Hours of Operations </div>
              <div v-for="hours in openHours" :key="hours">{{hours}}</div>
              <div v-if="restaurant.regularOpeningHours" class="open-close">{{ (restaurant.regularOpeningHours.openNow?"Open Now":"Currently Closed") }}</div>
          
            <div class="hover-box" v-if="showComments">

                <div class="hover-box-head">

                    <div>Comments</div>
                    <div class="hover-box-exit" @click="closeHoverBox">x</div>
                </div>
                <div class="hover-list">
                    <ul>
                        <li v-for="c in restaurant.comment" :key="c.username">{{ "(" + c.username + ")" + " " + c.comment }}</li>
                    </ul>
                </div>
            </div>
   
                        
</div>
        </div>

          <div :class="{'button-bar':isActive,'inactive-button-bar':!isActive}">
            <div class="up-down">
                <div class="tu-items">
                    <span v-if="!isActive">
                        {{ restaurant.countThumbsUp }}
                    </span>
                    <img class="thumbs-up" src="..\assets\yellowthumbdown.png" title="Yummy" alt="thumbs-up" @click="thumbup">
                </div>
                <div class="cm-items">
                    <span>
                        {{ restaurant.comment.length }}
                    </span>
                    <img class="comment-icon" src="..\assets\leaveAcomment.png" title="Show Comments" @click="displayComments($event)" alt="" id = 'comment-button'>
                </div>
                <div class="td-items">
                        <span v-if="!isActive">
                            {{ restaurant.countThumbsDown }} 
                        </span>
                        <img src="..\assets\yellowthumbdown.png" alt="thumbs-down" title="Yucky" @click="thumbdown">
                </div>

            </div>
          <!-- {{ restaurant }} -->
      </div>
  </div>
 
</template>


<script>
        import service from '../services/RestaurantService';
    
export default {
    props: ["restaurant"],
    data(){
        return {
            fullStarUrl: '',
            halfStarUrl: '',
            emptyStarUrl: '',
            comment:'',
            showComments: false
        }
    },
    methods: {
        displayComments(event){
            this.showComments = true; 
        },
        closeHoverBox(){
            this.showComments = false;            
        },
        getFullStars(){
            return Math.floor(Math.round(this.restaurant.rating * 2)/2);
        },
        getHalfStars(){
            if(Math.round(this.restaurant.rating * 2)/2 - this.getFullStars() == .5){
                return 1;
            }else{
                return 0;
            }
        },
        getEmptyStars(){
            return 5 - this.getFullStars() - this.getHalfStars();
        },
        getStarColor(){
            if(this.restaurant.rating > 3.5){
                return 'green';
            }else if(this.restaurant.rating > 2){
                return 'lime';
            }
            return 'yellow';
        },
        getStarUrl(type){
            return "/src/assets/" +this.getStarColor() + " " + type + ".png"
        },
        getImagePath(){
            return this.restaurant.image_url + '&maxHeightPx=400';
        },
        radians(deg){
            return (deg * Math.PI) / 180;
        },
        thumbup(){
            this.$store.commit("ADD_SELECTED", {id:this.restaurant.id,name:this.restaurant.name})

        },
        thumbdown(){
            this.$store.commit("DELETE_SELECTED", {id:this.restaurant.id,name:this.restaurant.name});
        },
        SaveComment(){
            let comment = {};
            comment.username = this.$store.state.user.username;
            comment.event_id = this.$store.state.event.id;
            comment.restaurant_id = this.restaurant.id;
            comment.comment = this.comment;
            service.SaveComment (comment).then(response => {
                // loop through comments and delete where user id=user.id
                let replaced = false;
                for(let i=0;i<this.restaurant.comment.length;i++){
                    if(this.restaurant.comment[i].username == this.$store.state.user.username){
                        this.restaurant.comment[i] = comment;
                        replaced = true;
                    }
                }
                if(!replaced){
                    this.restaurant.comment.push(comment);
                }               
                this.$store.commit('SET_MESSAGE', {text:'Comment Saved', type:'success'});
            });
        },
        
    },
    computed:{   
        formattedPhone(){
            return '+1' + this.restaurant.display_phone.replace('(','').replace(' ','').replace('-','').replace(')','');
        },  
        categoryList(){
            let cList = [];
            this.restaurant.categories.forEach((c)=>{
                if(c.indexOf('_restaurant') > 0){
                    cList.push(c.replace('_restaurant','').replace('_',' '));
                }
            });

            this.restaurant.transactions.forEach((c)=>{
                cList.push(c.toLowerCase());
            });

            return cList;
        },
        calculateDistance(){
            const pLat = this.restaurant.coordinates.latitude;
            const pLng = this.restaurant.coordinates.longitude;

            const eLat = this.$store.state.event.coordinates.latitude;
            const eLng = this.$store.state.event.coordinates.longitude;

            return parseFloat(Math.acos(Math.sin(this.radians(pLat))*Math.sin(this.radians(eLat))+Math.cos(this.radians(pLat))*Math.cos(this.radians(eLat))*Math.cos(this.radians(eLng)-this.radians(pLng)))*6371 * .621371).toFixed(2) + ' miles';
        },
        priceLevel(){
            const p = this.restaurant.price;

            if(p == null){return '$'}

            if(p.indexOf('FREE') > 0){
                return '$';
            }else if(p.indexOf('INEXPENSIVE') > 0){
                return '$$';
            }else if(p.indexOf('MODERATE') > 0){
                return '$$$';
            }else if(p.indexOf('EXPENSIVE') > 0){
                return '$$$$';
            }else{
                return '$$$$$';
            }
        },
        openHours(){
            if(this.restaurant.regularOpeningHours){
                return this.restaurant.regularOpeningHours.weekdayDescriptions;
            }else{
                return ['Hours Unavailable'];
            }
        },
        isActive(){
            let today = new Date();
            const dd = String(today.getDate()).padStart(2, '0');
            const mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
            const yyyy = today.getFullYear();

            today = yyyy + '-' + mm + '-' + dd;
            return this.$store.state.event.end_date >= today;        
        }
    },
    created(){
        this.halfStarUrl = this.getStarUrl('half');
        this.fullStarUrl = this.getStarUrl('full');
        this.emptyStarUrl = this.getStarUrl('empty');
    }

}
</script>


<style scoped>

.hover-box{
    position: fixed;
    top: 130px;
    left: 70px;
    padding:5px;
    height: 200px;
    background-color: #ffffff;
    border: solid 2px #63190fc0;
    border-radius: 15px;
    color: #000000;
    width: 260px;
  
}

.hover-box-head{
    background-color: #17a4e0;
    padding: 7px 10px 4px 5px;
    color: #ffffff;
    display: flex;
    justify-content: space-between;
    border-radius:7px;
    font-weight: bold;
}

.hover-box-exit{
    text-align: center;
    padding-bottom:3px; 
    font-weight: bold;
    background-color: #ffffff;
    color: #690e0e;
    width: 15px;
    height: 15px;
    cursor: pointer;
    
}

.hover-list{
    overflow-y: auto;
    height: 140px;
    border: solid 1px #63190fc0;
    margin-top: 10px;
    border-radius:10px;
    color: #000000;
    /* overflow-y: scroll; */ 

}

.hover-list ul {
    color:#000000;
    list-style-type: none;
    padding: 10px;
    margin: 0px;
}

.comment-box{
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    color: #0f0f0f;
    padding-top: 20px;
    font-size: 20px;
    font-weight: bold;
}
.comment-box label{

}
.comment-button{ 
    margin-top:10px;
    padding:5px;
}

.comment-button:hover{
    cursor: pointer;

}

textarea{
    padding: 5px;
    border-radius: 9px;
    resize: none;
    width: 200px;
    font-size: 16px;
}
    
.container {
    display: flex;
    flex-direction: column;
    max-width: 2000px;
    margin-left: 350px;
    margin-right: 20px;
    font-family: Arial, sans-serif;
    background-color: #63190fc0; /* Background color for the container */
    margin-top:15px;
}

.grid-container {
    display: grid;
    grid-template-columns: 1fr 1fr 1fr; /* Creates 3 equal columns */
    gap: 10px; /* Space between grid items */
    padding: 20px;
}

.phone{
    margin-top:10px;
    font-weight: bold;
    font-size:20px;
}

.title {
    grid-column: 1 / -1; /* The title spans all columns */
    color: #fcfbfb; /* Title text color */
    padding: 0px;
    text-align: center;
    font-size: 24px;
    border-radius: 5px; /* Rounded corners for the title */
}

.grid-item {
    background-color: hsla(0, 100%, 100%, 0.774); /* Background color for grid items */
    padding: 20px;
    border-radius: 5px; /* Rounded corners for grid items */    
}

.button-bar, .inactive-button-bar {
    grid-column: 1 / 3;
    align-content: center;
    height:50px;
    width: 100%;
    margin-bottom:15px;
}
.button-bar img, .inactive-button-bar img {
    width: 50px;
    height: 50px;
    margin: 20px;
    
}
.thumbs-up{
    transform: rotate(180deg);
}

.up-down{
    display: flex;
    align-items: center;
    font-size: 40px;
    font-weight: bold;
    color: #fcfbfb;
    width: 100%;
    justify-content: space-evenly;
}

.up-down span{
    margin: 0px 20px;
}

.button-bar img:hover{
    width: 72px;
    height: 72px;
    cursor: pointer;
}

.td-items, .tu-items, .cm-items{
    display: flex;
    align-items: center;
}

/* Specific styles for grid items */
.image img {
    width: 100%; /* Full width of the grid column */
    height: auto;
}



.rating-stars {
    color: #FFD700; /* Gold color for rating stars */
    font-size: 30px;
}

.rating-stars img {
    width: 17px;
    height: 17px;
}

.price-range {
    /* Style for price range */
    font-size: 18px;
}

.tags {
    /* Style for tags, possibly a smaller font size */
    margin-top: 10px;
    
}

.tags .tag {
    padding:3px;
    background-color:#111812c0;
    color:#ffffff;
    font-size:small; 
    margin-right:3px;
    border-radius: 3px;

}

.rating-number {
    font-weight: bold; /* Bold for rating number */
    color: black;
    font-size: 30px;
    margin-left:10px;
}

.review-count {
    font-size: smaller; /* Smaller font size for review count */
    color: black;
    font-size: 20px;
    white-space: nowrap;
}

.open-close {
    color: green; /* Green color for open status */
    font-size: 20px;
    font-weight: bold;
    margin-top: 20px;

}

.address {
    /* Style for address */
    margin-top: 20px;
    font-weight:bold;
    font-size: 20px;
}
.distance {
    /* Style for distance */
    margin-top: 10px;
}
.hours div {
    margin-bottom: 5px; /* Space between hours */
    
}
.HOP{
font-size: 20px;
color: #0f0f0f;
font-weight: bold;
padding-bottom: 20px;
}
.more-info{
    margin-top: 10px; 
}

.website-button{
    margin-left: 10px;
}

a {
    background-color: white;
    color: #b90e0e;
    border: solid 1px #b90e0e;
    padding: 5px;    
} 

@media only screen and (max-width: 1250px) and (min-width: 950px)  {
    .grid-container {
        display: grid;
        grid-template-columns: 1fr 1fr; /* Creates 3 equal columns */
        gap: 10px; /* Space between grid items */
        padding: 20px;
    }
}

@media only screen and (max-width: 950px)  {
    .grid-container {
        display: grid;
        grid-template-columns: 1fr; /* Creates 3 equal columns */
        gap: 10px; /* Space between grid items */
        padding: 20px;
    }
}

/* Add more styles as needed */
</style>