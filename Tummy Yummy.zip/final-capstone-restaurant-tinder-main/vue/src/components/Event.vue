<template>
    <div class="event">
        <div class="event-title">{{ ev.title }}</div>
        <div class="event-data">
            <div class="event-info">
                <span>Date: {{formattedDate }}</span>
                <span class="ev-time">Time: {{ formattedTime }}</span>
                <span class="ev-code">Event Code: {{ ev.id }}</span>
            </div>
            <div class="event-button">
                <button class="ev-button" v-if="isActive" @click="doMailTo">Generate Email</button>
                <button class="ev-button" v-if="isActive" @click="copyLinkToClipboard">Generate Link</button>
                <button class="ev-button" v-else @click="viewResults"> View Results</button>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    props: ['ev'],
    methods:{
        doMailTo(){
            window.open ( `mailto:?subject=Tummy%20Yummy%20Invitation%20-%20Gathering%23:%20${this.ev.id}%20for%20${this.formattedDate}%20at%20${this.formattedTime}&body=Your%20buddy%20wants%20your%20opinion%20on%20Tummy%20Yummy.%0D%0A%0D%0AThumbs%20up%20or%20Thumbs%20down%20your%20restaurant%20selections%20using%20the%20following%20Gathering%20Code%3A%20${this.ev.id}%0D%0A%0D%0AGo%20to%20TummyYummy.com%20to%20login%20and%20make%20your%20selections%20today.`, '_blank');
        },
        copyLinkToClipboard(){
            navigator.clipboard.writeText(window.location.protocol + '//' + window.location.hostname + ":" + window.location.port + '/vote/' + this.ev.id);
        },
        viewResults(){
            this.$router.push (`/vote/${this.ev.id}`);
        }
    },  
    computed: {
    
        formattedDate(){

            const dt_pts = this.ev.date.split("-");
            return dt_pts[1] + "/" + dt_pts[2] + "/" + dt_pts[0];

        }, 
        formattedTime(){
            const time_pts = this.ev.time.split(":");
                let suffix = "AM";

            if (time_pts[0] >=12){
                suffix = "PM";
            }
            
            if (time_pts[0] > 12){

                time_pts[0] = time_pts[0]-12;

            }
                    
            return time_pts[0]+ ":" + time_pts[1] + " " + suffix; 
        },
        isActive(){
            let today = new Date();
            const dd = String(today.getDate()).padStart(2, '0');
            const mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
            const yyyy = today.getFullYear();

            today = yyyy + '-' + mm + '-' + dd;
            return this.ev.end_date >= today;
        }
    } 
}

</script>
<style scoped>

span{
    margin-right: 5px;
}
.event-title{
    font-size: 40px ;
    color: rgb(250, 248, 248);
}
.event-info{
    font-size: 25px;
}

.ev-button{
    margin-left: 10px;
    background-color: #b90e0e;
    color: white;
    font-weight: bold;
    margin-bottom:20px;
    cursor: pointer;
}

.ev-code{
    margin-left:50px;
}

.ev-time{
    margin-left:10px;
}

.event {
    margin-bottom: 10px;
    width: 100%;
    display: flex;
    flex-direction: column;
    background-color: rgba(12, 4, 4, 0.491);
    padding: 10px 10px 0px 10px;

}

.event-data {
    display: flex;
    justify-content: space-between;
    align-items:center;
}
</style>