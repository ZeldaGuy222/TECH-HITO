<template>
    <h2>Create Gathering</h2>
    <h2> {{ title }}</h2>
    <form class="gather-form" v-on:submit.prevent="addNewEvent">
        <section>
            <div class="event-element">
                <label for="title" class="event-title">Title</label>
                <div class="location-box">
                    <input type="text" id="title" v-model="event.title" />
                </div>
            </div>

            <div class="event-element">
                <label for="dateOfGathering">Event Date</label>
                <input type="date" id="dateOfGathering" v-model="event.date" @blur="isValidDate" />
            </div>
            <div class="event-element">
                <label for="timeOfGathering">Event Time</label>
                <input type="time" id="timeOfGathering" v-model="event.time" />
            </div>
            <div class="event-element">
                <label for="endDate">Voting Ends</label>
                <input type="date" id="endDate" v-model="event.end_date" @blur="isValidEndDate" />
            </div>

            <div class="event-element">
                <label for="location" class="l-location">Location</label>
                <div class="location-box">
                    <input :disabled="currLocChecked" type="text" id="location" v-model="event.location" />
                </div>
            </div>
            <div class="event-element">
                <label for="currentLocation"> Or Current Location</label>
                <input type="checkbox" id="currentLocation" v-model="currLocChecked" @click="setCurrentLocation" />
            </div>
            <div class="event-element">
                <label for="radius">Radius (Miles)</label>
                <select id="radius" v-model="event.radius">
                    <option value="1600">1</option>
                    <option value="8000">5</option>
                    <option value="16000">10</option>
                    <option value="24000">15</option>
                    <option value="40000">25</option>
                </select>
            </div>
            <div class="event-element">
                <label for="dietary"> Options</label>
                <div>
                    <select id="dietary" v-model="dietaryScope">
                        <option value=""></option>
                        <option value="0">Has</option>
                        <option value="1">Only</option>
                    </select>
                    <select v-model="dietaryType">
                        <option value=""></option>
                        <option value="vegan">Vegan</option>
                        <option value="vegetarian">Vegetarian</option>
                    </select>
                </div>
            </div>
        </section>
        <input id="btnGetRest" type="button" value="Get Restaurants" @click="getRestaurantListing">
    </form>
</template>

<script>
import restaurantService from '../services/RestaurantService';

export default {
    props: ['title'],
    data(){
        return {
            event: {
                id: "",
                date: "",
                time: "",
                end_date: "",
                host_id: 0,
                selected_id: "",
                location: "",
                coordinates: {},
                isVegan: false,
                isVegetarian: false,
                isAllRest: false,
                restaurantList: {},
                radius: 0,
                guests: {},
            },
            currLocChecked: false,
        
            //vegetarian options
            dietaryType: null,
            //looking for only vegetarian or vegan, or just including results
            dietaryScope: null
        }
    },
    methods:{
        isValidDate(){
            const dt = document.getElementById('dateOfGathering');

            let today = new Date();
            const dd = String(today.getDate()).padStart(2, '0');
            const mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
            const yyyy = today.getFullYear();

            today = yyyy + '-' + mm + '-' + dd;

            if(dt.value < today){
                this.$store.commit('SET_MESSAGE',{text: 'Date entered must be greater than or equal to today.',type: 'info'});
                dt.focus();
            } 
               
        },
        isValidEndDate(){
            const dt = document.getElementById('dateOfGathering');
            const endDt = document.getElementById('endDate');

            let today = new Date();
            const dd = String(today.getDate()).padStart(2, '0');
            const mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
            const yyyy = today.getFullYear();

            today = yyyy + '-' + mm + '-' + dd;

            if(dt.value < endDt.value){
                this.$store.commit('SET_MESSAGE',{text: 'End Date must be less than or equal to Gathering Date.',type: 'info'});
                dt.focus();
            } 

            if(endDt.value < today){
                this.$store.commit('SET_MESSAGE',{text: 'End Date entered must be greater than or equal to today.',type: 'info'});
                dt.focus();
            } 
        },
        getEventId(){
            let eventId = "";
            let chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

            for( let i=0;i<5;i++ ){
                
                eventId += chars.charAt(Math.floor(Math.random() * 26));
            }
            return eventId;

        },
        getRestaurantListing(){
            if(this.event.radius == ''){
                alert('Radius is required');
                return;
            }

            if(this.event.location == ''){
                alert('Location is required');
                return;
            }

            if(this.event.time == ''){
                alert('Time is required');
                return;
            }
            
           this.event.isVegan=(this.dietaryType == "vegan"?true:false);
           this.event.isVegetarian=(this.dietaryType == "vegetarian"?true:false);
           this.event.isAllRest=(this.dietaryScope == "1" ?false:true);
                
           restaurantService.getRestaurants(this.event.location, this.event.radius,
           this.event.isVegan,
           this.event.isVegetarian,
           this.event.isAllRest)
           .then(response =>{
                this.event.restaurantList=response.data.restaurantList;
                this.event.coordinates.latitude = response.data.coordinates.latitude;
                this.event.coordinates.longitude = response.data.coordinates.longitude;
                this.$store.commit("SET_EVENT", this.event);
           })
           .catch(error => {
                console.log(error); 
           })
        },        
        setCurrentLocation(){
            if(!this.currLocChecked){
                if (navigator.geolocation) {
                    navigator.geolocation.getCurrentPosition(this.setPosition);
                } else {
                    alert("Geolocation is not supported by this browser.");
                }
            }else{
                this.event.location = '';
            }
        },
        setPosition(position) {       
            this.event.location =  position.coords.latitude  + ";" + position.coords.longitude ;  
            this.event.coordinates.latitude = position.coords.latitude;
            this.event.coordinates.longitude = position.coords.longitude;
        },
        
    },
    created(){    
        this.event.id = this.getEventId();
    },
}

</script>

<style scoped>
#btnGetRest{
    margin-top:10px;

}
#title{ 
    width: 230px;
}

.event-element{
    display: flex;
    justify-content: space-between;
    margin-top: 5px;
    font-size: 20px;
    align-items: center;
}

input[type='text'], input[type='date'],input[type='time'] {
    padding: 5px;
    border-radius: 5px;
    font-size: 20px;
    width: 150px;
}
select{
    padding: 5px;
    border-radius: 5px;
    font-size: 20px; 
}

.l-location{
    margin-right: 10px;
}
section{
    width: 300px;
    margin-left: 2px;
 
}
#dietary{
    margin-right: 5px;
}
.side-bar{
    margin-left: 8px;    
}
.R-List{
    background-color: brown(230, 63, 63);
    min-height: 100px;
    font-weight: bold;
    padding: 10px;
    text-align: left; 
    font-size: 18px;
    border-radius: 20px;
    border: solid 1px brown;
    text-align: center;
}
.R-List ul{
    margin-top:15px;
    text-align:left;
    font-size: 20px;
}
.R-List li{
   font-weight: bold;
    width: 190px;
    font-weight: normal;
    margin-top:2px;
}

.side-bar{
    position: absolute;
    margin-left: 20px
}
.gather-form{
    margin-bottom: 50px;
}
.submit-event-button{
    margin-top: 50px;
}
</style>