<template>
  <div id="capstone-app">
    <div id= "nav">
      <div class = 'logoDiv'>
      <img class='logo' src="src/assets\logo.png" alt="">
      <span class="title"> Tummy Yummy </span>
    </div>
      <div>
        <!-- <router-link v-bind:to="{ name: 'Bio' }" v-if="$store.state.token == ''">Bio</router-link> adding bio button -->
        <router-link v-bind:to="{ name: 'logout' }" v-if="$store.state.token != ''">Logout</router-link>
        <router-link v-bind:to="{ name: 'login' }" v-else>Log In</router-link>
        <router-link v-bind:to="{ name: 'login' }" v-if="$store.state.token == ''">Join Event</router-link>
        <router-link v-bind:to="{ name: 'user' }" v-else>Home</router-link>
        
        
      
      </div>
    </div>
    <message />
    <router-view />
  </div>
  
  <!-- {{ $store.state }} -->
</template>

<script>
import Message from './components/Message.vue';

export default{
  components:{
    Message
  },
}
</script>

<style>
body{
  font-family: Arial, Helvetica, sans-serif;
  margin: 0px;
}

#nav { background-color: rgb(15, 15, 15);
  display: flex;
  height: 75px;
  justify-content: space-between;
  align-items: center;
  padding: 0px 25px;
  color: rgb(243, 247, 244);
}
.logo {
  height: 60px;

}
.title {
  font-size: 2em;
  font-weight: bold;
  padding-left: 14px;
}
.logoDiv {
display: flex;
align-items: center;

}

a { 
  display: inline-block;
  padding: 10px;
  background-color: #b90e0e;
  border-radius: 10px;
  color: white;
  text-decoration: none;
  margin-left:10px;
  font-weight:bold;
}

input[type='button'], button{
  padding:7px;
  border-radius: 7px;
  font-weight: bold;
  font-size:15px;
  margin-top:15px;
}

input[type='text'], input[type='password']{
  padding: 5px;
  border-radius: 5px;
  font-size: 20px;
}

@media only screen and (max-width: 600px) and (min-width: 400px)  {

  
}

</style>