import { createStore as _createStore } from 'vuex';
import axios from 'axios';

export function createStore(currentToken, currentUser) {
  let store = _createStore({
    state: {
      token: currentToken || '',
      user: currentUser || {},
      event: {},
      restaurantFilter:[],
      selectedList:[],
      voting_event: null,
      message: {}
    },
    mutations: {
      SET_HOST_ID(state){
        state.event.host_id = state.user.id;
      },
      SORT_RESTAURANTS(state){
        state.event.restaurantList.sort((a,b)=>{
          return a.countThumbsDown - a.countThumbsUp; 
        });
      },
      CLEAR_EVENT(state)  {
          state.event = {};
          state.restaurantFilter = [];
          state.selectedList = [];
      },
      SET_MESSAGE(state,obj){
        state.message = obj;
      },
      SET_EVENT_RESTAURANTS(state){
        let selRestList = [];

        state.event.restaurantList.forEach((rest)=>{
           state.selectedList.forEach((sel)=>{
              if(sel.id == rest.id){
                selRestList.push(rest);
              }
           });
        });

        state.event.restaurantList = selRestList;              
      },
      SET_AUTH_TOKEN(state, token) {
        state.token = token;
        localStorage.setItem('token', token);
        axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
      },
      ADD_SELECTED (state, rest) {  //this is going to take in the thumb of a rests
        let exists = false;
        state.selectedList.forEach((r)=>{
          if(rest.id == r.id){
            exists = true;
          }
        });

        if(!exists){
          state.selectedList.push(rest);
        }
      },
      DELETE_SELECTED(state, rest){
        state.selectedList = state.selectedList.filter((r)=>{
          return r.id !== rest.id;
        });
      },
      SET_USER(state, user) {
        state.user = user;
        localStorage.setItem('user', JSON.stringify(user));
      },
      LOGOUT(state) {
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        state.token = '';
        state.user = {};
        this.commit('CLEAR_EVENT');
        axios.defaults.headers.common = {};
      },
      SET_EVENT(state,ev){
        state.event = ev;
      },
      SET_VOTING_EVENT(state, id){
            state.voting_event =id; 
      }
    },
  });
  return store;
}
