<template>
  <div class="header">
      <div class="side-bar" v-if="isActive">
          <selected-list :title="title" />
      </div>
      <RestaurantList />
  </div>
</template>

<script>
import RestaurantList from '../components/RestaurantList.vue';
import restaurantService from '../services/RestaurantService';
import eventsService from '../services/EventsService';
import SelectedList from '../components/Selected.vue';

export default {
  props: ['title'],
  components:{
      RestaurantList,
      SelectedList, 
  },
  beforeRouteLeave(){
      this.$store.commit('SET_MESSAGE' ,{});
  },
  beforeCreate(){
    if(!this.$store.state.user.id){
  //  alert('not today santa')
      this.$store.commit ('SET_VOTING_EVENT',this.$route.params.event_id);
      this.$router.push("/login");
      }

      eventsService.getEvent(this.$route.params.event_id)
    

    .then(response => {
      this.$store.commit('SET_EVENT',response.data);
      this.$store.commit('SORT_RESTAURANTS');

      if(!this.isActive){
        this.$store.commit('SET_MESSAGE',{text:'This event is no longer accepting votes',type:'info'});    
      }

    });  
  },
  computed:{
    isActive(){
            let today = new Date();
            const dd = String(today.getDate()).padStart(2, '0');
            const mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
            const yyyy = today.getFullYear();

            today = yyyy + '-' + mm + '-' + dd;
            return this.$store.state.event.end_date >= today;
    }
  }
};
  
</script>

<style scoped>
.side-bar{  
  position: fixed;
  margin-left: 20px
}
.comment-box{
  color: brown;
}

</style>