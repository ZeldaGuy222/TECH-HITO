<template>
  <event-form title="Create Gathering"/>
</template>

<script>

import EventForm from '../components/EventForm.vue';

export default {
  components: {
    EventForm,

  }


}
</script>

<style>

</style>