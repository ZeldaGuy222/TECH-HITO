<template>
  <div>
    Event Results View
  </div>

</template>

<script>
export default {

}
</script>

<style>

</style>