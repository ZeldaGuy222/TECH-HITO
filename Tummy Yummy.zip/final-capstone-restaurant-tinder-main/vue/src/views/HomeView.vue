<template>
  <div class="home">
    <div class="background">  
        <img src="src\assets\background.png" alt="">  
    </div>
    <div class="content"> 
        <h2> Tummy <br />Hungry? </h2> 
        <br>
        <h3> Let's Find Something<br />Yummy!</h3>
    </div>
  </div>
</template>

<script>
export default {
};
</script>


<style scoped>
img {
width: 100%;
height: 100vh;
}
.content{
  display: inline-block;
  position: absolute;
  width: 500px;
  height: 200px;
  top:0px;
  left:0px;
  right:0px;
  margin-left:auto;
  margin-right:auto;
  color: rgb(253, 250, 250);
}

.home {
  position: relative;
  display: flex;
  justify-content: space-between;
}

h2 {
  font-size: 4rem;
  margin: 0px;
  line-height: 1.4;
}
h3 {
  font-size: 2.5rem;
  margin: 0px;
  line-height: 1.5;
}
.background{
  width:100%;

  
}

</style>

