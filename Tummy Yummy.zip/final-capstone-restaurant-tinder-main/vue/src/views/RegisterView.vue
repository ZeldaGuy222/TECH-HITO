<template>
  <div class="reg-container">
    <div id="register" class="text-center">
      <form v-on:submit.prevent="register">
        <h1>Create Account</h1>
        <div role="alert" v-if="registrationErrors">
          {{ registrationErrorMsg }}
        </div>
        <div class="form-input-group">
          <label for="username">Username</label>
          <input type="text" id="username" v-model="user.username" required autofocus />
        </div>
        <div class="form-input-group">
          <label for="password">Password</label>
          <input type="password" id="password" v-model="user.password" required />
        </div>
        <div class="form-input-group">
          <label for="confirmPassword">Confirm Password</label>
          <input type="password" id="confirmPassword" v-model="user.confirmPassword" required />
        </div>
        <button type="submit">Create Account</button>
        <p><router-link v-bind:to="{ name: 'login' }">Already have an account? Log in.</router-link></p>
      </form>
    </div>
  </div>
</template>

<script>
import authService from '../services/AuthService';

export default {
  data() {
    return {
      user: {
        username: '',
        password: '',
        confirmPassword: '',
        role: 'user',
      },
      registrationErrors: false,
      registrationErrorMsg: 'There were problems registering this user.',
    };
  },
  methods: {
    register() {
      if (this.user.password.length < 8) {
        this.registrationErrors = true;
        this.registrationErrorMsg = "Your password needs a minimum of eight characters";
      } else if (this.user.password.search(/[a-z]/) < 0) {
        this.registrationErrors = true;
        this.registrationErrorMsg = "Your password needs a lower case letter";
      } else if(this.user.password.search(/[A-Z]/) < 0) {
        this.registrationErrors = true;
        this.registrationErrorMsg = "Your password needs an upper case letter";
      } else  if (this.user.password.search(/[0-9]/) < 0) {
        this.registrationErrors = true;
        this.registrationErrorMsg = "Your password needs a number";
      } else if (this.user.password != this.user.confirmPassword) {
        this.registrationErrors = true;
        this.registrationErrorMsg = 'Password & Confirm Password do not match.';
      } else {
        authService
          .register(this.user)
          .then((response) => {
            if (response.status == 201) {
              this.$router.push({
                path: '/login',
                query: { registration: 'success' },
              });
            }
          })
          .catch((error) => {
            const response = error.response;
            this.registrationErrors = true;
            if (response.status === 400) {
              this.registrationErrorMsg = response.data.message;
            }
          });
      }
    },
    clearErrors() {
      this.registrationErrors = false;
      this.registrationErrorMsg = 'There were problems registering this user.';
    },
  },
};
</script>

<style scoped>
.form-input-group {
  margin-bottom: 1rem;
  display:flex;
  justify-content: space-between;
  align-items: center;
}
label {
  margin-right: 0.5rem;
}

#register{
  display: inline-block;
  top:0px;
  left:0px;
  right:0px;
  margin-left:auto;
  margin-right:auto;
  color: black;
  border: solid 1px black;
  border-radius: 20px;
  padding: 20px;
  background-color: #ffffff;
  height:fit-content;
}

.reg-container {
  position: relative;
  display: flex;
  justify-content: space-between;
  padding-top:60px;
  background-image: url('../assets/background2.png');
  background-repeat: no-repeat;
  background-size: cover;
  height: 100vh;
}

h1 {
  margin-top: 5px;
}
</style>
