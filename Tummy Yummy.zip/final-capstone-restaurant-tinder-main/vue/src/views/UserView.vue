<template>
  <div class="outer">
    <div class="main">
      <div class="create-button button-format">
        <router-link :to="{ name: 'event', params: { 'event_id': '0' } }">Create a
          Gathering </router-link>
      </div>
      <div class="join-button button-format">
        <div class="vote">Ready To Vote?</div>
        <div class="code"><input type="text" name="txtCode" id="txtCode" placeholder="Enter Gathering Code"
            v-model="event_code"></div>
        <div class="go_vote"><router-link :to="{ path: `/vote/${event_code}` }">Vote</router-link>
        </div>
      </div>
      <div class="event-listing button-format" v-if="hosted_events.length > 0">
        <h2>Event Listing</h2>
        <Event :ev="hosted" v-bind:key="hosted.id" v-for="hosted in hosted_events"> </Event>
      </div>
    </div>
  </div>
</template>

<script>
import Event from '../components/Event.vue';
import EventsService from '../services/EventsService';

export default {
  components: {
    Event
  },
  data() {
    return {
      hosted_events: [],
      event_code: ""
    }
  },
  created() {
    EventsService.getEvents(this.$store.state.user.id)
    .then(response => {
        this.hosted_events = response.data;
    });
    
    this.$store.commit('CLEAR_EVENT');
  }

}
</script>

<style>

.main{
    display: flex;
    flex-direction: column ;
    font-family: Arial, sans-serif;
    margin: 0px 30px 50px 30px;
    justify-content: flex-start;    
    margin: 0;
    padding: 0;
} 
.create-button{
    font-size: 30px;
}
.join-button{
    font-size: 30px;
    color: white;
    font-weight: bold;
    padding: 15px;
    object-position:center ;
    object-fit: contain;
}
.event-listing{
  font-size: 30px;
    color: #ffffff;
    font-weight: bold;
    text-shadow: -1px -1px 0 #000, 1px -1px 0 #000, -1px 1px 0 #000, 1px 1px 0 #000;    
}
.button-format{  
    display: grid;
    max-width: auto;
    padding: 20px;
    font-family: Arial, sans-serif;
    background-repeat: no-repeat;
    background-size: cover;
    align-items: center;
    justify-items: center;
    margin-top: 50px;
}

a{
  display: inline-block;
  padding: 10 0px;
  background-color: #b90e0e;
  border-radius: 10px;
  color: white;
  text-decoration: none;
  margin-left:10  0px;
  font-weight:bold;
  padding: px;
}
.outer {
   background-image: url('../assets/eating.jpg');  
   background-size: cover;
   height: 100vh;
   background-attachment: fixed;
}

.vote{
  font-size: larger;
  text-shadow: -1px -1px 0 #000, 1px -1px 0 #000, -1px 1px 0 #000, 1px 1px 0 #000;
}
.go_vote{
  margin-top: 10px;  
}
</style>