<template>
    <div>
    Join View
    <router-link :to="{name: 'vote', params:{'event_id':'11111'}}">Vote for event I'm not hosting</router-link>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>