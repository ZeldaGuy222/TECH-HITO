BEGIN TRANSACTION;

DROP TABLE IF EXISTS users;

CREATE TABLE users (
	user_id SERIAL,
	username varchar(50) NOT NULL UNIQUE,
	password_hash varchar(200),
	role varchar(50) NOT NULL,
	full_name varchar(255),
	CONSTRAINT PK_user PRIMARY KEY (user_id)
);
DROP TABLE IF EXISTS comments;
CREATE TABLE comments (

    comment varchar (255),
    username varchar(255),
    restaurant_id varchar(255),
    event_id varchar (5),

CONSTRAINT PK_comments PRIMARY KEY (username, restaurant_id,event_id)

);
DROP TABLE IF EXISTS event;

CREATE TABLE event (
    id varchar(5) NOT NULL,
    title varchar(255),
    event_date varchar(20) NOT NULL,
    event_time varchar(20) NOT NULL,
    event_end_date varchar(20) NOT NULL,
    location varchar(255),
    location_latitude DECIMAL(11,8),
    location_longitude DECIMAL(11,8),
    radius int,
    host_id int,
    selected_id varchar(255),
    is_vegan boolean,
    is_vegetarian boolean,
    is_all_rest boolean,

    CONSTRAINT PK_event PRIMARY KEY (id)
);

DROP TABLE IF EXISTS event_restaurant;

CREATE TABLE event_restaurant (
    id SERIAL,
    restaurant_id varchar(255),
    event_id varchar(5),
    CONSTRAINT PK_event_event_restaurant PRIMARY KEY (id)
);

DROP TABLE IF EXISTS event_user;

CREATE TABLE event_user (
    id SERIAL,
    user_id int,
    event_id varchar(5),
    random_key varchar(255),
    is_complete boolean,
    CONSTRAINT PK_event_user PRIMARY KEY (id)
);


DROP TABLE IF EXISTS event_restaurant_user;

CREATE TABLE event_restaurant_user (
      event_id varchar(5),
      restaurant_id varchar(255),
      username varchar(50),
      vote boolean,
      CONSTRAINT PK_event_restaurant_user PRIMARY KEY (event_id,restaurant_id,username )
);

COMMIT TRANSACTION;

