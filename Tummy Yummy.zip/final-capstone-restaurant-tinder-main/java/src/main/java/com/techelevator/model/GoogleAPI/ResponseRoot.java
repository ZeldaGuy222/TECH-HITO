package com.techelevator.model.GoogleAPI;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.ArrayList;

public class ResponseRoot{
    @JsonProperty("places")
    public ArrayList<Place> getPlaces() {
        return this.places; }
    public void setPlaces(ArrayList<Place> places) {
        this.places = places; }
    ArrayList<Place> places;
}