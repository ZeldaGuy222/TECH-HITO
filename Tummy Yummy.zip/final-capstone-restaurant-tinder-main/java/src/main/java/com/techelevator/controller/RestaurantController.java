package com.techelevator.controller;

import com.techelevator.dao.EventDao;
import com.techelevator.dao.JdbcEventDao;
import com.techelevator.dao.JdbcRestaurantDao;
import com.techelevator.dao.RestaurantDao;
import com.techelevator.exception.DaoException;
import com.techelevator.model.Comment;
import com.techelevator.model.Event;
import com.techelevator.model.Restaurant;
import com.techelevator.services.RestaurantService;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.ArrayList;
import java.util.List;

@RestController
@CrossOrigin
@PreAuthorize("isAuthenticated()")
public class RestaurantController {
    private RestaurantDao restaurantDao;
    private RestaurantService restaurantService;

    public RestaurantController(JdbcRestaurantDao restaurantDao, JdbcEventDao eventDao) {
        this.restaurantDao = restaurantDao;
        this.restaurantService = new RestaurantService(eventDao, restaurantDao);
    }

    //Gets new event with restaurants from host based on area
    //search = zip code, city, state
    @RequestMapping(path = "/restaurants", method = RequestMethod.GET)
    public Event searchRest(@RequestParam String search, @RequestParam int radius, @RequestParam boolean vegan, @RequestParam boolean vegetarian, @RequestParam boolean allRest) {
        Event ev = null;

        try {
            ev = restaurantService.listRestaurants(search, radius, vegan, vegetarian, allRest, "0");
        } catch (DaoException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "An error occurred while attempting your request.");
        }
        return ev;
    }
// list of Restaurants by event ID
    @RequestMapping(path = "/restaurants/{event_id}", method = RequestMethod.GET)
    public Event searchRest( @PathVariable String event_id) {
        Event ev = null;

        try {
            ev = restaurantService.listRestaurants(event_id);
        } catch (DaoException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "An error occurred while attempting your request.");
        }
        return ev;
    }
    @ResponseStatus(HttpStatus.CREATED)
    @RequestMapping(path = "/restaurants/comments", method = RequestMethod.POST)
    public Comment addComment(@RequestBody Comment comment){

        try{
        restaurantService.addcomment(comment);
        } catch (DaoException e)
        {
        throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "An error occurred while attempting your request.");}

        return comment;
    }


}

