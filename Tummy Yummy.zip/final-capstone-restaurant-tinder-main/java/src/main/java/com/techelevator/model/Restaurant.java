package com.techelevator.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.techelevator.model.GoogleAPI.RegularOpeningHours;
import com.techelevator.model.YelpAPI.Attributes;
import com.techelevator.model.YelpAPI.Coordinates;
import com.techelevator.model.YelpAPI.Location;

import java.util.ArrayList;
import java.util.List;

public class Restaurant {
    private String name;
    private String phone;
    private double rating;
    private String price;
    private boolean vote;
    public String id;
    public String alias;
    public String image_url;
    public boolean is_closed;
    public String url;
    public int review_count;
    public ArrayList<String> categories = new ArrayList<>();
    public Coordinates coordinates = new Coordinates();
    @JsonProperty("transactions")
    public ArrayList<String> featureList = new ArrayList<>();
    public Location location = new Location();
    public String display_phone;
    public double distance;
    public Attributes attributes = new Attributes();
    public RegularOpeningHours regularOpeningHours;
    public int countThumbsUp;
    public int countThumbsDown;
    public ArrayList<Comment> comment = new ArrayList<>();

    public int getCountThumbsDown() {
        return countThumbsDown;
    }

    public void setCountThumbsDown(int countThumbsDown) {
        this.countThumbsDown = countThumbsDown;
    }


    public int getCountThumbsUp() {
        return countThumbsUp;
    }

    public void setCountThumbsUp(int countThumbsUp) {
        this.countThumbsUp = countThumbsUp;
    }

    public void setVote(boolean vote) {
        this.vote = vote;
    }

    public boolean getVote() {
        return vote;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAlias() {
        return alias;
    }

    public void setAlias(String alias) {
        this.alias = alias;
    }

    public String getImage_url() {
        return image_url;
    }

    public void setImage_url(String image_url) {
        this.image_url = image_url;
    }

    public boolean isIs_closed() {
        return is_closed;
    }

    public void setIs_closed(boolean is_closed) {
        this.is_closed = is_closed;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public int getReview_count() {
        return review_count;
    }

    public void setReview_count(int review_count) {
        this.review_count = review_count;
    }

    public void setCategories(ArrayList<String> categories) {
        this.categories = categories;
    }

    public Coordinates getCoordinates() {
        return coordinates;
    }

    public void setCoordinates(Coordinates coordinates) {
        this.coordinates = coordinates;
    }

    public void setFeatureList(ArrayList<String> featureList) {
         this.featureList = featureList;
    }

    public Location getLocation() {
        return location;
    }

    public void setLocation(Location location) {
        this.location = location;
    }

    public String getDisplay_phone() {
        return display_phone;
    }

    public void setDisplay_phone(String display_phone) {
        this.display_phone = display_phone;
    }

    public double getDistance() {
        return distance;
    }

    public void setDistance(double distance) {
        this.distance = distance;
    }

    public Attributes getAttributes() {
        return attributes;
    }

    public void setAttributes(Attributes attributes) {
        this.attributes = attributes;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public double getRating() {
        return rating;
    }

    public void setRating(double rating) {
        this.rating = rating;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public List<String> getFeatureList() {
        return featureList;
    }

    public List<String> getCategories() {
        return categories;
    }
}


