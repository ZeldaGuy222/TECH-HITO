package com.techelevator.model.GoogleAPI;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Open{
    @JsonProperty("day")
    public int getDay() {
        return this.day; }
    public void setDay(int day) {
        this.day = day; }
    int day;
    @JsonProperty("hour")
    public int getHour() {
        return this.hour; }
    public void setHour(int hour) {
        this.hour = hour; }
    int hour;
    @JsonProperty("minute")
    public int getMinute() {
        return this.minute; }
    public void setMinute(int minute) {
        this.minute = minute; }
    int minute;
}
