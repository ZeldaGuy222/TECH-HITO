package com.techelevator.model.GoogleAPI;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.ArrayList;

public class Photo{
    @JsonProperty("name")
    public String getName() {
        return this.name; }
    public void setName(String name) {
        this.name = name; }
    String name;
    @JsonProperty("widthPx")
    public int getWidthPx() {
        return this.widthPx; }
    public void setWidthPx(int widthPx) {
        this.widthPx = widthPx; }
    int widthPx;
    @JsonProperty("heightPx")
    public int getHeightPx() {
        return this.heightPx; }
    public void setHeightPx(int heightPx) {
        this.heightPx = heightPx; }
    int heightPx;
    /*@JsonProperty("authorAttributions")
    public ArrayList<AuthorAttribution> getAuthorAttributions() {
        return this.authorAttributions; }
    public void setAuthorAttributions(ArrayList<AuthorAttribution> authorAttributions) {
        this.authorAttributions = authorAttributions; }
    ArrayList<AuthorAttribution> authorAttributions;*/
}
