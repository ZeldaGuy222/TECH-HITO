package com.techelevator.dao;

import com.techelevator.model.Comment;
import java.util.ArrayList;

public interface RestaurantDao {


        boolean existsInEvent(String event_id, String restId);

        int getThumbsUpCount(String event_id, String restaurant_id);

        int getThumbsDownCount(String event_id, String restaurant_id);

        ArrayList<Comment> getcomments(String event_id, String restaurant_id);

        void addcomment(Comment comments);

}
