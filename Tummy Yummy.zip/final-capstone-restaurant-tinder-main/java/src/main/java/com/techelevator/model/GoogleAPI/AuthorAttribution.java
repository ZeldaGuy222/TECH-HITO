package com.techelevator.model.GoogleAPI;

import com.fasterxml.jackson.annotation.JsonProperty;

public class AuthorAttribution{
    @JsonProperty("displayName")
    public String getDisplayName() {
        return this.displayName; }
    public void setDisplayName(String displayName) {
        this.displayName = displayName; }
    String displayName;
    @JsonProperty("uri")
    public String getUri() {
        return this.uri; }
    public void setUri(String uri) {
        this.uri = uri; }
    String uri;
    @JsonProperty("photoUri")
    public String getPhotoUri() {
        return this.photoUri; }
    public void setPhotoUri(String photoUri) {
        this.photoUri = photoUri; }
    String photoUri;
}