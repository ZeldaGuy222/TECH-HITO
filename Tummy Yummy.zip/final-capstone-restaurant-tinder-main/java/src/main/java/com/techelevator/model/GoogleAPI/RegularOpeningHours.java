package com.techelevator.model.GoogleAPI;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.ArrayList;

public class RegularOpeningHours{
    @JsonProperty("openNow")
    public boolean getOpenNow() {
        return this.openNow; }
    public void setOpenNow(boolean openNow) {
        this.openNow = openNow; }
    boolean openNow;
    @JsonProperty("periods")
    public ArrayList<Period> getPeriods() {
        return this.periods; }
    public void setPeriods(ArrayList<Period> periods) {
        this.periods = periods; }
    ArrayList<Period> periods;
    @JsonProperty("weekdayDescriptions")
    public ArrayList<String> getWeekdayDescriptions() {
        return this.weekdayDescriptions; }
    public void setWeekdayDescriptions(ArrayList<String> weekdayDescriptions) {
        this.weekdayDescriptions = weekdayDescriptions; }
    ArrayList<String> weekdayDescriptions;
}
