package com.techelevator.model.YelpAPI;

import com.techelevator.model.Restaurant;

import java.util.ArrayList;

public class YelpQuery {
    //public ArrayList<Restaurant> businesses;
    public Region region;
}
