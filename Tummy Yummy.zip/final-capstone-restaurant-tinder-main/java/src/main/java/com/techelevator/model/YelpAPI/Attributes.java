package com.techelevator.model.YelpAPI;

public class Attributes{
    public String menu_url;
}

