package com.techelevator.model.YelpAPI;

import java.util.ArrayList;

public class Location{
    public String address1;
    public String address2;
    public String address3;
    public String city;
    public String zip_code;
    public String country;
    public String state;
    public ArrayList<String> display_address;
}
