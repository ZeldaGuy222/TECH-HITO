package com.techelevator.model.GoogleAPI;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.ArrayList;

public class Place{
    @JsonProperty("id")
    public String getId() {
        return this.id; }
    public void setId(String id) {
        this.id = id; }
    String id;
    @JsonProperty("types")
    public ArrayList<String> getTypes() {
        return this.types; }
    public void setTypes(ArrayList<String> types) {
        this.types = types; }
    ArrayList<String> types;
    @JsonProperty("formattedAddress")
    public String getFormattedAddress() {
        return this.formattedAddress; }
    public void setFormattedAddress(String formattedAddress) {
        this.formattedAddress = formattedAddress; }
    String formattedAddress;
    @JsonProperty("location")
    public Location getLocation() {
        return this.location; }
    public void setLocation(Location location) {
        this.location = location; }
    Location location;
    @JsonProperty("rating")
    public double getRating() {
        return this.rating; }
    public void setRating(double rating) {
        this.rating = rating; }
    double rating;
    @JsonProperty("userRatingCount")
    public int getUserRatingCount() {
        return this.userRatingCount; }
    public void setUserRatingCount(int userRatingCount) {
        this.userRatingCount = userRatingCount; }
    int userRatingCount;
    @JsonProperty("displayName")
    public DisplayName getDisplayName() {
        return this.displayName; }
    public void setDisplayName(DisplayName displayName) {
        this.displayName = displayName; }
    DisplayName displayName;
    @JsonProperty("takeout")
    public boolean getTakeout() {
        return this.takeout; }
    public void setTakeout(boolean takeout) {
        this.takeout = takeout; }
    boolean takeout;
    @JsonProperty("delivery")
    public boolean getDelivery() {
        return this.delivery; }
    public void setDelivery(boolean delivery) {
        this.delivery = delivery; }
    boolean delivery;
    @JsonProperty("photos")
    public ArrayList<Photo> getPhotos() {
        return this.photos; }
    public void setPhotos(ArrayList<Photo> photos) {
        this.photos = photos; }
    ArrayList<Photo> photos;
    @JsonProperty("nationalPhoneNumber")
    public String getNationalPhoneNumber() {
        return this.nationalPhoneNumber; }
    public void setNationalPhoneNumber(String nationalPhoneNumber) {
        this.nationalPhoneNumber = nationalPhoneNumber; }
    String nationalPhoneNumber;
    @JsonProperty("websiteUri")
    public String getWebsiteUri() {
        return this.websiteUri; }
    public void setWebsiteUri(String websiteUri) {
        this.websiteUri = websiteUri; }
    String websiteUri;
    @JsonProperty("regularOpeningHours")
    public RegularOpeningHours getRegularOpeningHours() {
        return this.regularOpeningHours; }
    public void setRegularOpeningHours(RegularOpeningHours regularOpeningHours) {
        this.regularOpeningHours = regularOpeningHours; }
    RegularOpeningHours regularOpeningHours;
    @JsonProperty("priceLevel")
    public String getPriceLevel() {
        return this.priceLevel; }
    public void setPriceLevel(String priceLevel) {
        this.priceLevel = priceLevel; }
    String priceLevel;
}
