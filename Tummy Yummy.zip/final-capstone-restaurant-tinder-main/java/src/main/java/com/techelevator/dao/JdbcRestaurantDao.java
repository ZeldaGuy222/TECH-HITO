package com.techelevator.dao;

import com.techelevator.exception.DaoException;
import com.techelevator.model.Comment;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ResponseStatusException;

import java.util.ArrayList;
import java.util.List;

@Component
public class JdbcRestaurantDao implements RestaurantDao {

    private final JdbcTemplate jdbcTemplate;

    public JdbcRestaurantDao(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public boolean existsInEvent(String event_id, String restId) {

        boolean exists = false;

        String getRestaurantSql = "Select event_id, restaurant_id FROM event_restaurant WHERE event_id = ? AND restaurant_id = ?";
        try {
            SqlRowSet results = jdbcTemplate.queryForRowSet(getRestaurantSql, event_id, restId);
            exists = results.next();
        } catch (
                CannotGetJdbcConnectionException e) {
            throw new DaoException("Unable to connect to server or database", e);
        } catch (
                DataIntegrityViolationException e) {
            throw new DaoException("Data integrity violation", e);
        }

        return exists;
    }

    @Override
    public ArrayList<Comment> getcomments(String event_id, String restaurant_id) {

        String getThumbsUpCountSql = "SELECT * FROM comments WHERE event_id=? AND restaurant_id=?";
        ArrayList<Comment> comments = new ArrayList<>();
        try {
            SqlRowSet results = jdbcTemplate.queryForRowSet(getThumbsUpCountSql, event_id, restaurant_id);
            while (results.next()) {
                comments.add(mapcomment(results));

            }
        } catch (
                CannotGetJdbcConnectionException e) {
            throw new DaoException("Unable to connect to server or database", e);
        } catch (
                DataIntegrityViolationException e) {
            throw new DaoException("Data integrity violation", e);
        }
        return comments;
    }

    @Override
    public int getThumbsUpCount(String event_id, String restaurant_id) {
        String getThumbsUpCountSql = "SELECT username FROM  event_restaurant_user WHERE event_id=? AND restaurant_id=?";
        int thumbCount = 0;
        try {
            SqlRowSet results = jdbcTemplate.queryForRowSet(getThumbsUpCountSql, event_id, restaurant_id);
            while (results.next()) {
                thumbCount++;
            }
        } catch (
                CannotGetJdbcConnectionException e) {
            throw new DaoException("Unable to connect to server or database", e);
        } catch (
                DataIntegrityViolationException e) {
            throw new DaoException("Data integrity violation", e);
        }
        return thumbCount;
    }

    @Override
    public int getThumbsDownCount(String event_id, String restaurant_id) {
        String getThumbsDownCountSql = "SELECT temp.username as voters FROM (SELECT DISTINCT username FROM event_restaurant_user WHERE event_id =?) as temp";
        int thumbCount = 0;
        try {
            SqlRowSet results = jdbcTemplate.queryForRowSet(getThumbsDownCountSql, event_id);
            while (results.next()) {
                thumbCount++;
            }
        } catch (
                CannotGetJdbcConnectionException e) {
            throw new DaoException("Unable to connect to server or database", e);
        } catch (
                DataIntegrityViolationException e) {
            throw new DaoException("Data integrity violation", e);
        }
        thumbCount = thumbCount - getThumbsUpCount(event_id, restaurant_id);
        return thumbCount;
    }

    @Override
    public void addcomment(Comment comments) {
        String insertCommentSql = "INSERT INTO comments ( comment, username, restaurant_id, event_id ) values (?,?,?,?)";
        String deleteCommentSql = "DELETE FROM comments WHERE event_id=? AND username=? AND restaurant_id=? ";
        try {
            jdbcTemplate.update(deleteCommentSql, comments.event_id, comments.username, comments.restaurant_id);
            jdbcTemplate.update(insertCommentSql, comments.comment, comments.username, comments.restaurant_id, comments.event_id);
        } catch (DaoException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
        }
    }

    private Comment mapcomment(SqlRowSet results) {
        Comment com = new Comment();
        com.username = results.getString("username");
        com.event_id = results.getString("event_id");
        com.restaurant_id = results.getString("restaurant_id");
        com.comment = results.getString("comment");

        return com;
    }
}