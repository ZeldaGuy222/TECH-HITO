package com.techelevator.model;

public class Comment {

    public String comment;
    public String restaurant_id;
    public String event_id;
    public String username;

}
