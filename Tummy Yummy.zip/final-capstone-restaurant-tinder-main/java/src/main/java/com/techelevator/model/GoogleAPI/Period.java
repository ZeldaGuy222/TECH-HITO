package com.techelevator.model.GoogleAPI;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Period{
    @JsonProperty("open")
    public Open getMyopen() {
        return this.myopen; }
    public void setMyopen(Open myopen) {
        this.myopen = myopen; }
    Open myopen;
    @JsonProperty("close")
    public Close getClose() {
        return this.close; }
    public void setClose(Close close) {
        this.close = close; }
    Close close;
}