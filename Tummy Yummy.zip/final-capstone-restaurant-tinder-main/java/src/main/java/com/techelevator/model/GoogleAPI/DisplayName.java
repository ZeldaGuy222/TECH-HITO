package com.techelevator.model.GoogleAPI;

import com.fasterxml.jackson.annotation.JsonProperty;

public class DisplayName{
    @JsonProperty("text")
    public String getText() {
        return this.text; }
    public void setText(String text) {
        this.text = text; }
    String text;
    @JsonProperty("languageCode")
    public String getLanguageCode() {
        return this.languageCode; }
    public void setLanguageCode(String languageCode) {
        this.languageCode = languageCode; }
    String languageCode;
}
