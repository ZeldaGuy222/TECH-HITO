package com.techelevator.controller;

import com.techelevator.dao.EventDao;
import com.techelevator.dao.JdbcEventDao;
import com.techelevator.dao.JdbcRestaurantDao;
import com.techelevator.dao.RestaurantDao;
import com.techelevator.exception.DaoException;
import com.techelevator.model.Event;
import com.techelevator.model.User;
import com.techelevator.services.RestaurantService;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.security.Principal;
import java.util.List;


@RestController
@CrossOrigin
@PreAuthorize("isAuthenticated()")
public class EventController {

    private EventDao eventDao;
    private RestaurantDao restaurantDao;
    private RestaurantService restaurantService;

    public EventController(JdbcEventDao eventDao, JdbcRestaurantDao restaurantDao) {
        this.restaurantService = new RestaurantService(eventDao, restaurantDao);
        this.restaurantDao = restaurantDao;
        this.eventDao = eventDao;
    }

    //posting an event created by host
    @RequestMapping(path = "/events", method = RequestMethod.POST)
    public Event createEvent(@RequestBody Event event) {
        Event ev;

        try {
            ev = eventDao.createEvent(event);
        } catch (DaoException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "An error occurred while attempting your request.");
        }

        return ev;
    }

    //getting list of events by user id
    @RequestMapping(path = "/events", method = RequestMethod.GET)
    public List<Event> getEvents(Principal p) {
        List<Event> eventList;
        try {
            eventList = eventDao.getEventsByUser(p.getName());
        } catch (DaoException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "An error occurred while attempting your request.");
        }
        return eventList;
    }

    //get a single event
    @RequestMapping(path = "/events/{id}", method = RequestMethod.GET)
    public Event getSingleEvent(@PathVariable ("id") String id) {
        Event event;

        try {
            event = restaurantService.listRestaurants(id);
        } catch (DaoException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "An error occurred while attempting your request.");
        }
        return event;
    }

    //updates event
    @RequestMapping(path = "/events/{id}", method = RequestMethod.PUT)
    public Event updateEvent( Principal p, @RequestBody Event event, @PathVariable  ("id") String id) {

        try {
            event = eventDao.updateUserVote(event,p.getName());
        } catch (DaoException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
        }
        return event;

    }

}
