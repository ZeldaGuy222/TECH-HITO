package com.techelevator.model;

import com.techelevator.model.YelpAPI.Coordinates;

import java.util.ArrayList;
import java.util.List;

public class Event {
    public String title;
    public String id;
    public String date;
    public String time;
    public String end_date;
    public int host_id;
    public String selected_id;
    public String location; //zip or city/state
    public Coordinates coordinates = new Coordinates();
    public boolean isVegan, isVegetarian, isAllRest;
    public List<Restaurant> restaurantList = new ArrayList<>();
    public int radius;

    public List<Restaurant> getRestaurantList() {
        return restaurantList;
    }

    public void setRestaurantList(List<Restaurant> restaurantList) {
        this.restaurantList = restaurantList;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public int getRadius() {
        return radius;
    }

    public void setRadius(int radius) {
        this.radius = radius;
    }
}
