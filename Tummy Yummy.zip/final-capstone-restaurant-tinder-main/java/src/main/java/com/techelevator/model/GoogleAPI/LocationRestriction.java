package com.techelevator.model.GoogleAPI;

import com.fasterxml.jackson.annotation.JsonProperty;

public class LocationRestriction{
    @JsonProperty("circle")
    public Circle getCircle() {
        return this.circle; }
    public void setCircle(Circle circle) {
        this.circle = circle; }
    Circle circle;
}
