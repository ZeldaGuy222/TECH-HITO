package com.techelevator.model.YelpAPI;

public class Region {
    public Coordinates center;
}
