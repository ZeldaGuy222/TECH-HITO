package com.techelevator.model.YelpAPI;

import com.fasterxml.jackson.annotation.JsonProperty;
import jdk.jfr.Name;
import org.springframework.data.mapping.Alias;

public class Category {

    public String alias;
    public String title;

    /*
    public Category(int id, String categoryAlias, String categoryText) {
        this.id = id;
        this.categoryAlias = categoryAlias;
        this.categoryText = categoryText;
    }
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCategoryAlias() {
        return categoryAlias;
    }

    public void setCategoryAlias(String categoryAlias) {
        this.categoryAlias = categoryAlias;
    }

    public String getCategoryTitle() {
        return categoryText;
    }

    public void setCategoryTitle(String categoryText) {
        this.categoryText = categoryText;
    }

     */



}
