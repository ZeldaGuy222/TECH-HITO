package com.techelevator.dao;

import com.techelevator.model.Event;
import java.util.List;

    public interface EventDao {

        Event getEventById(String id);

        List<Event> getEventsByUser(String username);

        Event createEvent(Event event);

        Event updateUserVote (Event ev,String userName);
    }


