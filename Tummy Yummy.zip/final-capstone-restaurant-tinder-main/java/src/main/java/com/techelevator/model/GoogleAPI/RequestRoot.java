package com.techelevator.model.GoogleAPI;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.ArrayList;

public class RequestRoot {
    @JsonProperty("includedTypes")
    public ArrayList<String> getIncludedTypes() {
        return this.includedTypes; }
    public void setIncludedTypes(ArrayList<String> includedTypes) {
        this.includedTypes = includedTypes; }
    ArrayList<String> includedTypes;

    @JsonProperty("excludedTypes")
    public ArrayList<String> getExcludedTypes() {
        return this.excludedTypes; }
    public void setExcludedTypes(ArrayList<String> excludedTypes) {
        this.excludedTypes = excludedTypes; }
    ArrayList<String> excludedTypes;

    @JsonProperty("maxResultCount")
    public int getMaxResultCount() {
        return this.maxResultCount; }
    public void setMaxResultCount(int maxResultCount) {
        this.maxResultCount = maxResultCount; }
    int maxResultCount;

    @JsonProperty("locationRestriction")
    public LocationRestriction getLocationRestriction() {
        return this.locationRestriction; }
    public void setLocationRestriction(LocationRestriction locationRestriction) {
        this.locationRestriction = locationRestriction; }
    LocationRestriction locationRestriction;

    @JsonProperty("rankPreference")
    public String getRankPreference() {
        return this.rankPreference; }
    public void setRankPreference(String rankPreference) {
        this.rankPreference = rankPreference; }
    String rankPreference;

}
