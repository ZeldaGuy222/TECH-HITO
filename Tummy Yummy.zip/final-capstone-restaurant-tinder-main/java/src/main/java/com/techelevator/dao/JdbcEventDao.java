package com.techelevator.dao;


import com.techelevator.exception.DaoException;
import com.techelevator.model.Event;
import com.techelevator.model.Restaurant;
import com.techelevator.model.User;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class JdbcEventDao implements EventDao {

    private final JdbcTemplate jdbcTemplate;

    public JdbcEventDao(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public Event getEventById(String id) {
        Event newEvent = new Event();
        String selectEventSql = "Select title, id, event_date, event_time, event_end_date, location, location_latitude, location_longitude, radius, host_id, selected_id, is_vegan,is_vegetarian,is_all_rest FROM event WHERE id = ?";

        try{
            SqlRowSet result = jdbcTemplate.queryForRowSet(selectEventSql, id);
            if (result.next()) {
                newEvent = mapEvent(result);
            }
        }catch (CannotGetJdbcConnectionException e) {
            throw new DaoException("Unable to connect to server or database", e);
        } catch (DataIntegrityViolationException e) {
            throw new DaoException("Data integrity violation", e);
        }
        return newEvent;
    }

    @Override
    public List<Event> getEventsByUser(String username){
        List<Event> eventList = new ArrayList<>();
        Map<String,Event> eventMap = new HashMap<>();

        String selectEventSql = "Select DISTINCT users.username,event_restaurant_user.username,title, id, event_date, event_time, event_end_date, location, location_latitude, location_longitude, radius, host_id, selected_id, is_vegan,is_vegetarian,is_all_rest FROM event LEFT JOIN users ON event.host_id=users.user_id LEFT JOIN event_restaurant_user ON event.id = event_restaurant_user.event_id WHERE users.username = ? OR event_restaurant_user.username = ?;";

        try{
            SqlRowSet result = jdbcTemplate.queryForRowSet(selectEventSql, username, username);
            while (result.next()) {
                Event newEvent = mapEvent(result);
                eventMap.put(newEvent.id, newEvent);
            }
        }catch (CannotGetJdbcConnectionException e) {
            throw new DaoException("Unable to connect to server or database", e);
        } catch (DataIntegrityViolationException e) {
            throw new DaoException("Data integrity violation", e);
        }

        for(Map.Entry<String,Event> e: eventMap.entrySet()){
            eventList.add(e.getValue());
        }
        return eventList;
    }

    @Override
    public Event createEvent(Event event){
        Event newEvent = null;

//        String eventId = "";
//        String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
//
//        for(int i=0;i<5;i++){
//            eventId += chars.charAt((int)Math.floor(Math.random() * 26));
//        }

//        event.id = eventId;

        String insertEventSql = "INSERT INTO event (id, title, event_date, event_time, event_end_date, location, location_latitude, location_longitude, radius, host_id,is_vegan,is_vegetarian,is_all_rest) values (?,?,?,?,?,?,?,?,?,?,?,?,?) RETURNING id";
        String insertEventRestaurantSql = "INSERT INTO event_restaurant ( restaurant_id, event_id ) values (?,?) RETURNING id";
        //String insertUserSql = "INSERT INTO user (username, role, full_name) values (?,?,?) ON conflict (username) DO NOTHING";
        //String insertUserRestaurantSql = "INSERT INTO event_restaurant_user (event_id, restaurant_id, username) values (?,?,?)";
        //String insertEventUserSql = "INSERT INTO event_user (event_id, username, is_complete) values (?, ?, ?)";

        try {
            /* for(User u : event.guests){
                jdbcTemplate.update(insertUserSql,u.getUsername(),"ANON_ROLE", u.getName() );
                jdbcTemplate.update(insertEventUserSql, event.id, u.getUsername(), false);
            }*/

            String newEventId = jdbcTemplate.queryForObject(insertEventSql, String.class, event.id, event.title, event.date, event.time, event.end_date, event.location, event.coordinates.latitude, event.coordinates.longitude, event.radius,event.host_id,event.isVegan,event.isVegetarian,event.isAllRest);
            event.id=newEventId;
            for(Restaurant r : event.restaurantList){
                int newEventRestaurantId = jdbcTemplate.queryForObject(insertEventRestaurantSql, int.class, r.id, newEventId);

                /*for(User u : event.guests){
                    jdbcTemplate.update(insertUserRestaurantSql,newEventRestaurantId, u.getUsername());
                }*/

            }
           //newEvent = getEventById(newEventId);
            newEvent = event;
        } catch (CannotGetJdbcConnectionException e) {
            throw new DaoException("Unable to connect to server or database", e);
        } catch (DataIntegrityViolationException e) {
            throw new DaoException("Data integrity violation", e);
        }
        return newEvent;
    }

    @Override
    public Event updateUserVote (Event ev, String userName) {
        //User u = new JdbcUserDao(jdbcTemplate).getUserById(ev.host_id);

        String deleteEventEvSql = "DELETE FROM event_restaurant_user WHERE event_id=? AND username=? ";
        String insertEventEvSql = "INSERT INTO event_restaurant_user (event_id,restaurant_id,username,vote) VALUES (?,?,?,true)";

        jdbcTemplate.update(deleteEventEvSql, ev.id, userName);

        for (Restaurant r : ev.restaurantList) {
            jdbcTemplate.update(insertEventEvSql, ev.id, r.id, userName);
        }

        return ev;
    }

    private Event mapEvent( SqlRowSet results){
        Event ev = new Event();
        ev.title = results.getString("title");
        ev.id = results.getString("id");
        ev.isVegetarian = results.getBoolean("is_vegetarian");
        ev.isVegan = results.getBoolean("is_vegan");
        ev.isAllRest = results.getBoolean("is_all_rest");
        ev.coordinates.latitude = results.getDouble("location_latitude");
        ev.coordinates.longitude = results.getDouble("location_longitude");
        ev.radius = results.getInt("radius");
        ev.selected_id = results.getString("selected_id");
        ev.end_date = results.getString("event_end_date");
        ev.time = results.getString("event_time");
        ev.date = results.getString("event_date");
        ev.host_id = results.getInt("host_id");

        return ev;
    }
}


