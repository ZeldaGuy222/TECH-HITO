package com.techelevator.services;

import com.techelevator.dao.JdbcEventDao;
import com.techelevator.dao.JdbcRestaurantDao;
import com.techelevator.exception.DaoException;
import com.techelevator.model.Comment;
import com.techelevator.model.GoogleAPI.*;
import com.techelevator.model.YelpAPI.YelpQuery;
import com.techelevator.model.Event;
import com.techelevator.model.Restaurant;
import org.springframework.http.*;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestClientResponseException;
import org.springframework.web.client.RestTemplate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class RestaurantService {

    private static final String Yelp_URL = "https://api.yelp.com/v3/businesses/";
    private static final String Yelp_Token = "NzFhsmrRmODmh8HKbiRZ-2lGvhCtF0G-GcembWr5BtV50hyClsnGPT-as5lJ1oOuUgB4hDgy9BixP3scSnZcGGUMD69rye9fnRfJK23m8zBoEFMojMcRNzlsgKsNZnYx";

    private static final String Google_URL = "https://places.googleapis.com/v1/places:searchNearby";

    private final RestTemplate restTemplate = new RestTemplate();

    private final JdbcEventDao jdbcEventDao;
    private final JdbcRestaurantDao jdbcRestaurantDao;

    private Map<String,Restaurant> restMap;

    public RestaurantService(JdbcEventDao jdbcEventDao, JdbcRestaurantDao jdbcRestaurantDao)  {
        this.jdbcEventDao = jdbcEventDao;
        this.jdbcRestaurantDao = jdbcRestaurantDao;
        this.restMap = new HashMap<>();
    }

    // want to get a map the results to a  model
    public Event listRestaurants(String search, int radius, boolean vegan, boolean vegetarian, boolean allRest, String event_id ) {
        Restaurant[] restaurants = null;
        Event ev = new Event();
        Center cntr = new Center();
        boolean useCoords = false;
        restMap = new HashMap<>();

        if (search.contains(";")) {
            cntr.setLatitude(Double.parseDouble(search.split(";")[0]));
            cntr.setLongitude(Double.parseDouble(search.split(";")[1]));
            useCoords = true;
        }
        try {
            YelpQuery regionFromYelp = null;
            if(!useCoords) {


                // perform yelp request to get coordinates
                HttpHeaders headers = new HttpHeaders();
                headers.setBearerAuth(Yelp_Token);
                HttpEntity<Void> entity = new HttpEntity<>(headers);

                ResponseEntity<YelpQuery> response = restTemplate.exchange(
                        Yelp_URL + "search?term=restaurant&location=" + search + "&radius=" + radius, HttpMethod.GET, entity, YelpQuery.class);
                regionFromYelp = response.getBody();
            }
            // setup googleHeaders
            HttpHeaders googleHeaders = new HttpHeaders();
            googleHeaders.setContentType(MediaType.APPLICATION_JSON);
            googleHeaders.add("X-Goog-Api-Key","AIzaSyAePIgSlDWYUdgbfp-2azXVlDS7__qfmj4");
            googleHeaders.add("X-Goog-FieldMask","places.id,places.displayName,places.photos,places.formattedAddress,places.nationalPhoneNumber,places.location,places.types,places.priceLevel,places.delivery,places.takeout,places.regularOpeningHours,places.websiteUri,places.userRatingCount,places.rating");

            RequestRoot googleReq = new RequestRoot();
            HttpEntity<RequestRoot> googleEntity;
            ResponseEntity<ResponseRoot> googleResponse;
            ResponseRoot googleData;

            ArrayList<String> includeList = new ArrayList<>();
            ArrayList<String> excludeList = new ArrayList<>();

            excludeList.add("fast_food_restaurant");
            excludeList.add("pizza_restaurant");
            excludeList.add("meal_takeaway");
            excludeList.add("shopping_mall");
            excludeList.add("grocery_store");

            googleReq.setExcludedTypes(excludeList);

            googleReq.setMaxResultCount(20);
            googleReq.setRankPreference("DISTANCE");

            LocationRestriction loc = new LocationRestriction();
            Circle cir = new Circle();
            if(!useCoords) {
                cntr.setLatitude(regionFromYelp.region.center.latitude);
                cntr.setLongitude(regionFromYelp.region.center.longitude);
            }
            cir.setCenter(cntr);
            cir.setRadius(radius);
            loc.setCircle(cir);

            googleReq.setLocationRestriction(loc);

            if(allRest) {
                includeList = new ArrayList<>();
                includeList.add("restaurant");
                googleReq.setIncludedTypes(includeList);

                googleEntity = new HttpEntity<>(googleReq, googleHeaders);
                googleResponse = restTemplate.exchange(
                        Google_URL, HttpMethod.POST, googleEntity, ResponseRoot.class);
                googleData = googleResponse.getBody();

                ev = addDataToEvent(ev,googleData);
            }

            if(vegan) {
                // vegan request
                includeList.clear();
                includeList.add("vegan_restaurant");
                googleReq.setIncludedTypes(includeList);

                googleEntity = new HttpEntity<>(googleReq, googleHeaders);
                googleResponse = restTemplate.exchange(
                        Google_URL, HttpMethod.POST, googleEntity, ResponseRoot.class);
                googleData = googleResponse.getBody();
                ev = addDataToEvent(ev,googleData);
            } else if(vegetarian) {
                // vegetarian request
                includeList.clear();
                includeList.add("vegetarian_restaurant");
                googleReq.setIncludedTypes(includeList);

                googleEntity = new HttpEntity<>(googleReq, googleHeaders);
                googleResponse = restTemplate.exchange(
                        Google_URL, HttpMethod.POST, googleEntity, ResponseRoot.class);
                googleData = googleResponse.getBody();
                ev = addDataToEvent(ev,googleData);
            }
                if (!useCoords) {
                    ev.coordinates = regionFromYelp.region.center;
                    ev.location = search;
                }
                else{
                    ev.coordinates.latitude = cntr.getLatitude();
                    ev.coordinates.longitude = cntr.getLongitude();
                }
                ev.radius = radius;

        } catch (RestClientResponseException e) {
            throw new DaoException(e.getMessage());
        } catch (ResourceAccessException e) {
            throw new DaoException(e.getMessage());
        }

        return ev;
    }

    public Event listRestaurants( String event_id ) {
        Restaurant[] restaurants = null;
        Event ev = jdbcEventDao.getEventById(event_id);
        restMap = new HashMap<>();
        
        try {
            // setup googleHeaders
            HttpHeaders googleHeaders = new HttpHeaders();
            googleHeaders.setContentType(MediaType.APPLICATION_JSON);
            googleHeaders.add("X-Goog-Api-Key","AIzaSyAePIgSlDWYUdgbfp-2azXVlDS7__qfmj4");
            googleHeaders.add("X-Goog-FieldMask","places.id,places.displayName,places.photos,places.formattedAddress,places.nationalPhoneNumber,places.location,places.types,places.priceLevel,places.delivery,places.takeout,places.regularOpeningHours,places.websiteUri,places.userRatingCount,places.rating");

            RequestRoot googleReq = new RequestRoot();
            HttpEntity<RequestRoot> googleEntity;
            ResponseEntity<ResponseRoot> googleResponse;
            ResponseRoot googleData;

            ArrayList<String> includeList = new ArrayList<>();
            ArrayList<String> excludeList = new ArrayList<>();

            excludeList.add("fast_food_restaurant");
            excludeList.add("pizza_restaurant");
            excludeList.add("meal_takeaway");
            excludeList.add("shopping_mall");
            excludeList.add("grocery_store");

            googleReq.setExcludedTypes(excludeList);

            googleReq.setMaxResultCount(20);
            googleReq.setRankPreference("DISTANCE");

            LocationRestriction loc = new LocationRestriction();
            Circle cir = new Circle();
            Center cntr = new Center();
            cntr.setLatitude(ev.coordinates.latitude);
            cntr.setLongitude(ev.coordinates.longitude);
            cir.setCenter(cntr);
            cir.setRadius(ev.radius);
            loc.setCircle(cir);

            googleReq.setLocationRestriction(loc);

            if(ev.isAllRest) {
                includeList = new ArrayList<>();
                includeList.add("restaurant");
                googleReq.setIncludedTypes(includeList);

                googleEntity = new HttpEntity<>(googleReq, googleHeaders);
                googleResponse = restTemplate.exchange(
                        Google_URL, HttpMethod.POST, googleEntity, ResponseRoot.class);
                googleData = googleResponse.getBody();

                ev = addDataToEventWithCheck(ev,googleData);
            }

            if(ev.isVegan) {
                // vegan request
                includeList.clear();
                includeList.add("vegan_restaurant");
                googleReq.setIncludedTypes(includeList);

                googleEntity = new HttpEntity<>(googleReq, googleHeaders);
                googleResponse = restTemplate.exchange(
                        Google_URL, HttpMethod.POST, googleEntity, ResponseRoot.class);
                googleData = googleResponse.getBody();
                ev = addDataToEventWithCheck(ev,googleData);
            } else if(ev.isVegetarian) {
                // vegetarian request
                includeList.clear();
                includeList.add("vegetarian_restaurant");
                googleReq.setIncludedTypes(includeList);

                googleEntity = new HttpEntity<>(googleReq, googleHeaders);
                googleResponse = restTemplate.exchange(
                        Google_URL, HttpMethod.POST, googleEntity, ResponseRoot.class);
                googleData = googleResponse.getBody();
                ev = addDataToEventWithCheck(ev,googleData);
            }



        } catch (RestClientResponseException e) {
            throw new DaoException(e.getMessage());
        } catch (ResourceAccessException e) {
            throw new DaoException(e.getMessage());
        }

        return ev;
    }

    private Event addDataToEvent(Event e,ResponseRoot data){
        Restaurant r;
        try {
           if(data.getPlaces() == null){
               return e;
           }

            for (Place p : data.getPlaces()) {
                if(restMap.containsKey(p.getId())){
                    continue;
                }

                r = new Restaurant();
                r.categories = p.getTypes();
                r.coordinates.latitude = p.getLocation().getLatitude();
                r.coordinates.longitude = p.getLocation().getLongitude();
                if (p.getDelivery()) {
                    r.featureList.add("Delivery");
                }
                if (p.getTakeout()) {
                    r.featureList.add("Takeout");
                }
                r.display_phone = p.getNationalPhoneNumber();
                r.id = p.getId();
                if(p.getPhotos().size() > 0){
                    r.image_url = "https://places.googleapis.com/v1/" + p.getPhotos().get(0).getName() + "/media?key=AIzaSyAePIgSlDWYUdgbfp-2azXVlDS7__qfmj4";
                }
                String[] addrParts = p.getFormattedAddress().split(",");

                r.location.address1 = addrParts[0].trim();
                r.location.city = addrParts[1].trim();
                r.location.state = addrParts[2].trim().split(" ")[0].trim();
                try {
                    r.location.zip_code = addrParts[2].trim().split(" ")[1].trim();
                }catch(Exception ex){}
                r.review_count = p.getUserRatingCount();
                r.url = p.getWebsiteUri();
                r.setRating(p.getRating());
                r.setName(p.getDisplayName().getText());
                r.setPrice(p.getPriceLevel());
                r.regularOpeningHours = p.getRegularOpeningHours();

                restMap.put(r.id,r);
                e.restaurantList.add(r);

            }
        }catch(Exception ex){
            System.out.println(ex.getMessage());
        }
        return e;
    }

    private Event addDataToEventWithCheck(Event e,ResponseRoot data){
        Restaurant r;
        try {
            if(data.getPlaces() == null){
                return e;
            }

            for (Place p : data.getPlaces()) {
                if(restMap.containsKey(p.getId())){
                    continue;
                }

                if(!jdbcRestaurantDao.existsInEvent(e.id, p.getId())){
                    continue;
                }

                r = new Restaurant();
                r.comment = jdbcRestaurantDao.getcomments(e.id, p.getId());
                r.categories = p.getTypes();
                r.coordinates.latitude = p.getLocation().getLatitude();
                r.coordinates.longitude = p.getLocation().getLongitude();
                if (p.getDelivery()) {
                    r.featureList.add("Delivery");
                }
                if (p.getTakeout()) {
                    r.featureList.add("Takeout");
                }
                r.display_phone = p.getNationalPhoneNumber();
                r.id = p.getId();
                if(p.getPhotos().size() > 0){
                    r.image_url = "https://places.googleapis.com/v1/" + p.getPhotos().get(0).getName() + "/media?key=AIzaSyAePIgSlDWYUdgbfp-2azXVlDS7__qfmj4";
                }
                String[] addrParts = p.getFormattedAddress().split(",");

                r.location.address1 = addrParts[0].trim();
                r.location.city = addrParts[1].trim();
                r.location.state = addrParts[2].trim().split(" ")[0].trim();
                try {
                    r.location.zip_code = addrParts[2].trim().split(" ")[1].trim();
                }catch(Exception ex){}
                r.countThumbsUp= jdbcRestaurantDao.getThumbsUpCount(e.id, r.id);
                r.countThumbsDown= jdbcRestaurantDao.getThumbsDownCount(e.id, r.id);
                r.review_count = p.getUserRatingCount();
                r.url = p.getWebsiteUri();
                r.setRating(p.getRating());
                r.setName(p.getDisplayName().getText());
                r.setPrice(p.getPriceLevel());
                r.regularOpeningHours = p.getRegularOpeningHours();

                restMap.put(r.id,r);
                e.restaurantList.add(r);

            }
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return e;
    }

    public void addcomment (Comment comments){
        jdbcRestaurantDao.addcomment(comments);
    }

}
