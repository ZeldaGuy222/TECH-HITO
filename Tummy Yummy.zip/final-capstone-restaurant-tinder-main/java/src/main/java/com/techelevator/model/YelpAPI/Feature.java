package com.techelevator.model.YelpAPI;

public class Feature {

    private int id;
    private String featureAlias;
    private String featureText;

    public Feature(int id, String featureAlias, String featureText) {
        this.id = id;
        this.featureAlias = featureAlias;
        this.featureText = featureText;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFeatureAlias() {
        return featureAlias;
    }

    public void setFeatureAlias(String featureAlias) {
        this.featureAlias = featureAlias;
    }

    public String getFeatureText() {
        return featureText;
    }

    public void setFeatureText(String featureText) {
        this.featureText = featureText;
    }
}
