package com.techelevator.model.YelpAPI;

public class Coordinates{
    public double latitude;
    public double longitude;
}
