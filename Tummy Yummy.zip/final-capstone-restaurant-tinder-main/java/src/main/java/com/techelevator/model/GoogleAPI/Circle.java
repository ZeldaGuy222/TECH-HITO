package com.techelevator.model.GoogleAPI;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Circle{
    @JsonProperty("center")
    public Center getCenter() {
        return this.center; }
    public void setCenter(Center center) {
        this.center = center; }
    Center center;
    @JsonProperty("radius")
    public double getRadius() {
        return this.radius; }
    public void setRadius(double radius) {
        this.radius = radius; }
    double radius;
}
